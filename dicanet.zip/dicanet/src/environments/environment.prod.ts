export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyCJKcmwZDvsh55_SeQU-LQ0dvYUnD44W-U',
    authDomain: 'dickernet-30e8e.firebaseapp.com',
    databaseURL: 'https://dickernet-30e8e.firebaseio.com',
    projectId: 'dickernet-30e8e',
    storageBucket: 'dickernet-30e8e.appspot.com',
    messagingSenderId: '848182412987',
    appId: '1:848182412987:web:e760c22526ce5c60'
  }
};
