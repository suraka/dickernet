import { NgModule } from '@angular/core';

import { 
    MatIconModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    MatStepperModule,
    MatSelectModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatBadgeModule,
    MatChipsModule,
    MatRippleModule,
    MatDialogModule,
    MatBottomSheetModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatCardModule,
    MatCheckboxModule,
    MatRadioModule,
    MatTableModule,
    MatSlideToggleModule,
    MatListModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
} from '@angular/material';

export const MAT_MODULES = [
    MatIconModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    MatStepperModule,
    MatSelectModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatBadgeModule,
    MatChipsModule,
    MatRippleModule,
    MatDialogModule,
    MatBottomSheetModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatCardModule,
    MatCheckboxModule,
    MatRadioModule,
    MatTableModule,
    MatSlideToggleModule,
    MatListModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule
];

@NgModule({
    imports: MAT_MODULES,
    exports: MAT_MODULES
})

export class MaterialModules { }