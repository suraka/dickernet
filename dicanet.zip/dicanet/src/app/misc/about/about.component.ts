import { Component, OnInit } from '@angular/core';
import { routerTransition } from './../../shared/animations';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss'],
  animations: [routerTransition()]
})
export class AboutComponent implements OnInit {

  public pagedItemsCount: number;
  public isStepOneCompleted = true;
  public isStepTwoCompleted = false;
  public isStepThreeCompleted = false;
  public isStepFourCompleted = false;

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0); // Scroll up
  }

  // Introduction
  toggleStepOne() {
    this.isStepOneCompleted = !this.isStepOneCompleted;
    this.isStepTwoCompleted = !this.isStepTwoCompleted;
  }

  // How it works?
  toggleStepTwo() {
    this.isStepTwoCompleted = !this.isStepTwoCompleted;
    this.isStepThreeCompleted = !this.isStepThreeCompleted;
  }

  // Oportunities
  toggleStepThree() {
    this.isStepThreeCompleted = !this.isStepThreeCompleted;
    this.isStepFourCompleted = !this.isStepFourCompleted;
  }

}
