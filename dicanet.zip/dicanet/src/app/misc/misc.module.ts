import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { MiscRoutingModule } from './misc-routing.module';
import { MaterialModules } from './../material';
import { SharedModule } from './../shared';

import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PolicyComponent } from './policy/policy.component';
import { TermsComponent } from './terms/terms.component';

export const COMPONENTS = [
  AboutComponent, 
  ContactComponent,
  PolicyComponent,
  TermsComponent
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MiscRoutingModule,
    MaterialModules,
    SharedModule,
  ]
})
export class MiscModule { }
