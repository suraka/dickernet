import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as firebase from 'firebase/app';

import { AngularFirestore } from '@angular/fire/firestore';

import { MessageService } from './../../core/services';
import { Message } from './../../core/models';
import { routerTransition } from './../../shared/animations';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
  animations: [routerTransition()]
})
export class ContactComponent implements OnInit {

  public contactForm: FormGroup;
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router, 
    private _location: Location,
    private _afs: AngularFirestore,
    private _snackBar: MatSnackBar,
    private message: MessageService
  ) {
    // Contact form
    this.contactForm = this.formBuilder.group({
      fullname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      message: ['', [Validators.required]],
      newsletter: ['']
    });
  }

  ngOnInit() {
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  // go back to previous location
  goBack() {
    this._location.back();
  }
  
  // Getter easy access to form fields
  get contact() { return this.contactForm.controls; }

  /**
   * onSubmit
   */
  public async onSubmit() {
    this.isLoading = true;
    this.error = null;

    if (this.contactForm.invalid) {
      return this.error = 'Ad could not be submitted';
    }

    // create document reference, id
    const mid = this._afs.createId();

    // access form fields
    const { fullname, email, phone, message, newsletter } = this.contactForm.value;

    const data: Message = {
      mid,
      fullname,
      email,
      phone,
      message,
      type: 'contact',
      seen: false,
      created: firebase.firestore.Timestamp.now().toMillis()
    }

    const title = 'Message';
    const msg = `Your message was sent to info.dickernet@gmail.com successfully.`;

    try {
      await this.message.createMessageDocument(data);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
    this.contactForm.reset();
    this.router.navigate(['']);
    this.openSnackBar(msg, title);
  }
}
