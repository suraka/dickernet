import { Component, OnInit } from '@angular/core';
import { routerTransition } from './../../shared/animations';

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.scss'],
  animations: [routerTransition()],
})
export class TermsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0); // Scroll up
  }

}
