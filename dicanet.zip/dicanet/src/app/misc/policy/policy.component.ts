import { Component, OnInit } from '@angular/core';
import { routerTransition } from './../../shared/animations';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.scss'],
  animations: [routerTransition()]
})
export class PolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0); // Scroll up
  }

}
