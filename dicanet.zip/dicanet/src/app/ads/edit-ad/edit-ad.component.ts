import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';

import * as firebase from 'firebase/app';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { AuthService, AdService, KeywordsService, ImageCompressionService } from './../../core/services';
import { Ad, Picture } from './../../core/models';
import { 
  TYPES, CATEGORIES, PROPERTIES, SERVICES, ELECTRONICS, TECHNOLOGY, FURNITURES, AUTOMOBILES, 
  BODY, CARS, TRICYCLES, TRUCKVANBUS, HEAVYDUTY, REGIONS, TRANSMISSION, FUEL, ENGINE
} from './../../core/constants.data';

import { routerTransition } from './../../shared/animations';
import * as utility from './../../core/utility';

@Component({
  selector: 'app-edit-ad',
  templateUrl: './edit-ad.component.html',
  styleUrls: ['./edit-ad.component.scss'],
  animations: [routerTransition()],
  // Encapsulation has to be disabled in order for the
  // component style to apply to the select panel.
  //encapsulation: ViewEncapsulation.None,
})
export class EditAdComponent implements OnInit, OnDestroy {

  public isLinear = true; // allow user to move next after required fields are completed
  public introAdForm: FormGroup;
  public detailsAdForm: FormGroup;
  public contactAdForm: FormGroup;
  public miscInfoAdForm: FormGroup;
  public types = TYPES;
  public regions = REGIONS;
  public categories = CATEGORIES;
  public properties = PROPERTIES;
  public services = SERVICES;
  public electronics = ELECTRONICS;
  public technology = TECHNOLOGY;
  public furnitures = FURNITURES;
  public automobiles = AUTOMOBILES;
  public bodyTypes = BODY;
  public transmissions = TRANSMISSION;
  public fuels = FUEL;
  public engines = ENGINE;
  public cars = CARS;
  public tricycles = TRICYCLES;
  public trucks = TRUCKVANBUS;
  public heavyDuties = HEAVYDUTY;

  private _uid: string;
  private _aid: string;
  public isLoading: boolean = false;
  public colorSlideToggle: string = 'primary';
  public swap: boolean = false;
  public action: 'login' | 'signup' = 'login'; // action property default to login
  public error: string;
  public ad$: Observable<Ad>;
  private _adSubscription: Subscription;
  public subcategory = new FormControl('');
  public color = new FormControl('');
  public brand = new FormControl('');
  public model = new FormControl('');
  public year = new FormControl('');
  public mileage = new FormControl('');
  public transmission = new FormControl('');
  public fuel = new FormControl('');
  public engine = new FormControl('');
  public body = new FormControl('');

  constructor(
    private _location: Location,
    private _formBuilder: FormBuilder,
    private _route: ActivatedRoute,
    private _afs: AngularFirestore,
    public auth: AuthService,
    private _ad: AdService,
    private _snackBar: MatSnackBar,
    private _keywords: KeywordsService,
  ) {
    // access user id and aid
    this._uid = this._route.snapshot.paramMap.get('id');
    this._aid = this._route.snapshot.paramMap.get('aid');

    // access ad document in firestore
    const adDoc: AngularFirestoreDocument<Ad> = this._afs.doc<Ad>(`ads/${this._aid}`);
    this.ad$ = adDoc.valueChanges();
  }

  ngOnInit() {
    this.introAdForm = this._formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      type: ['', Validators.required],
      category: ['', Validators.required],
      price: ['', Validators.required]
    });

    this.detailsAdForm = this._formBuilder.group({});
    /* this.detailsAdForm = this._formBuilder.group({
      subcategory: [''], // <--- for vehicles|automobiles, services, properties, furnitures, electronics 
      brand: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      model: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      year: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      color: [''], // <--- for all categories
      mileage: [''], // <--- for cars, heavy duty, tricycle motors, trucks vans buses
      transmission: [''], // e.g.: automatic or manuel <--- for cars, heavy duty, tricycle motors, trucks vans buses
      fuel: [''], // e.g.: electric, petrol, diesel or gas <--- for cars, heavy duty, tricycle motors, trucks vans buses
      engine: [''], // e.g.: four cylinder <--- for cars, heavy duty, tricycle motors, trucks vans buses
      body: [''], // e.g.: saloon <--- for cars, heavy duty, tricycle motors, trucks vans buses
    }); */

    this.miscInfoAdForm = this._formBuilder.group({
      status: [''],
      negotiable: [''],
      swapping: ['']
    });

    this.contactAdForm = this._formBuilder.group({
      phone: ['', Validators.required],
      address: this._formBuilder.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        region: ['', Validators.required]
      })
    });

    this._adSubscription = this.ad$.subscribe(resp => {      
      // set defaults for introduction
      this.introAdForm.setValue({
        title: resp.title, description: resp.description,
        type: resp.type,
        category: resp.category,
        price: resp.price
      });

      // set defaults for details
      this.subcategory.setValue(resp.subcategory, {onlySelf: true, emitEvent: true});
      this.color.setValue(resp.color, {onlySelf: true, emitEvent: true});
      this.brand.setValue(resp.brand, {onlySelf: true, emitEvent: true});
      this.model.setValue(resp.model, {onlySelf: true, emitEvent: true});
      this.year.setValue(resp.year, {onlySelf: true, emitEvent: true});
      this.mileage.setValue(resp.mileage, {onlySelf: true, emitEvent: true});
      this.transmission.setValue(resp.transmission, {onlySelf: true, emitEvent: true});
      this.fuel.setValue(resp.fuel, {onlySelf: true, emitEvent: true});
      this.engine.setValue(resp.engine, {onlySelf: true, emitEvent: true});
      this.body.setValue(resp.body, {onlySelf: true, emitEvent: true});

      // set defaults for additional information
      this.miscInfoAdForm.setValue({
        status: resp.status, negotiable: resp.negotiable, swapping: resp.swapping
      });
      
      // set defaults for contact information
      this.contactAdForm.setValue({
        phone: resp.phone, 
        address: { 
          street: resp.address.street, 
          city: resp.address.city, 
          region: resp.address.region 
        }
      });
      
    });

    //this.uploadPicturesAdForm = this._formBuilder.group({});
  }

  ngOnDestroy() {
    if (this._adSubscription) {
      this._adSubscription.unsubscribe();
    }
  }

  // go back to previous location
  goBack() {
    this._location.back();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  // access to form fields
  get intro() { return this.introAdForm.controls; }
  // get details() { return this.detailsAdForm.controls; }

  // process data and add it to firestore as an ad
  async onSubmitPostAdForm() {
    let data: Ad;
    this.isLoading = true;
    this.error = null;

    if (this.introAdForm.invalid || this.miscInfoAdForm.invalid || this.contactAdForm.invalid) {
      return this.error = 'Ad could not be submitted';
    }

    // access form fields
    const { title, description, type, category, price  } = this.introAdForm.value;
    // const { subcategory, brand, model, year, color, mileage, transmission, fuel, engine, body } = this.detailsAdForm.value;
    const { status, negotiable, swapping } = this.miscInfoAdForm.value;
    const { phone, address } = this.contactAdForm.value;

    // generate keywords
    const keywords = this._keywords.generateKeywords(utility.toLowerCase(title));

    data = {
      uid: this._uid,
      aid: this._aid,
      title, description, 
      type, category, price,
      status, negotiable, swapping, 
      phone, 
      address: { 
        street: address.street, 
        city: address.city, 
        region: address.region 
      },
      subcategory: this.subcategory.value ? this.subcategory.value : null, 
      color: this.color.value ? this.color.value : null, 
      brand: this.brand.value ? this.brand.value : null, 
      model: this.model.value ? this.model.value : null,
      year: this.year.value ? this.year.value : null,  
      mileage: this.mileage.value ? this.mileage.value : null, 
      transmission: this.transmission.value ? this.transmission.value : null, 
      fuel: this.fuel.value ? this.fuel.value : null, 
      engine: this.engine.value ? this.engine.value : null, 
      body: this.body.value ? this.body.value : null,
      public: false,
      keywords,
      updated: firebase.firestore.Timestamp.now().toMillis()
    };
    
    try {
      console.log(data);
      await this._ad.updateAdDocument(data);
      this.introAdForm.reset();
      this.detailsAdForm.reset();
      this.miscInfoAdForm.reset();
      this.contactAdForm.reset();

      const title = 'Edit Ad';
      const msg = 'Ad was updated successful.';

      this.goBack();
      this.openSnackBar(msg, title);
    } catch(error) { 
      console.log(error.message) ;
      this.error = error.message;
    }

    this.isLoading = false;
  }

}