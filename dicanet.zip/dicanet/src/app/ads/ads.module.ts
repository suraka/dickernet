import { NgModule, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { LazyLoadImageModule } from 'ng-lazyload-image';

import { AdsRoutingModule } from './ads-routing.module';
import { MaterialModules } from './../material';
import { SharedModule } from './../shared';

import { PostAdComponent } from './post-ad/post-ad.component';
import { ViewAdComponent, FeedbackBottomSheetComponent } from './view-ad/view-ad.component';
import { EditAdComponent } from './edit-ad/edit-ad.component';

export const COMPONENTS = [
  PostAdComponent,
  ViewAdComponent,
  EditAdComponent,
  FeedbackBottomSheetComponent
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    LazyLoadImageModule,
    AdsRoutingModule,
    MaterialModules,
    SharedModule,
  ],
  entryComponents: [
    FeedbackBottomSheetComponent
  ]
})
export class AdsModule { }
