import { createAction, union, props } from '@ngrx/store';
import { Ad } from '../../core/models';

/**
 * Add Ad to Collection Action
 */
export const addAd = createAction(
  '[Selected Ad Page] Add Ad',
  props<{ ad: Ad }>()
);

/**
 * Remove Ad from Collection Action
 */
export const removeAd = createAction(
  '[Selected Ad Page] Remove Ad',
  props<{ ad: Ad }>()
);

const all = union({ addAd, removeAd });

export type SelectedAdPageActionsUnion = typeof all;
