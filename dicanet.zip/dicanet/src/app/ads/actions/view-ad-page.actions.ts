import { createAction, props } from '@ngrx/store';

export const selectAd = createAction(
  '[View Ad Page] Select Ad',
  props<{ aid: string }>()
);

export type ViewAdPageActionsUnion = ReturnType<typeof selectAd>;
