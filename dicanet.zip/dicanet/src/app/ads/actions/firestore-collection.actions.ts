import { createAction, props, union } from '@ngrx/store';
import { Ad } from './../../core/models';

/**
 * Post Ad to Firestore Collection Actions
 */
export const postAdSuccess = createAction(
  '[Collection/AngularFirestore] Post Ad Success',
  props<{ ad: Ad }>()
);

export const postAdFailure = createAction(
  '[Collection/AngularFirestore] Post Ad Failure',
  props<{ ad: Ad }>()
);

/**
 * Remove Ad from Firestore Collection Actions
 */
export const removeAdSuccess = createAction(
  '[Collection/AngularFirestore] Remove Ad Success',
  props<{ ad: Ad }>()
);

export const removeAdFailure = createAction(
  '[Collection/AngularFirestore] Remove Ad Failure',
  props<{ ad: Ad }>()
);

/**
 * Load Ads from Firestore Collection Actions
 */
export const loadAdsSuccess = createAction(
  '[Collection/AngularFirestore] Load Ads Success',
  props<{ ads: Ad[] }>()
);

export const loadAdsFailure = createAction(
  '[Collection/AngularFirestore] Load Ads Failure',
  props<{ error: any }>()
);

const all = union({
    postAdSuccess,
    postAdFailure,
    removeAdSuccess,
    removeAdFailure,
    loadAdsSuccess,
    loadAdsFailure,
});
export type FirestoreCollectionActionsUnion = typeof all;
