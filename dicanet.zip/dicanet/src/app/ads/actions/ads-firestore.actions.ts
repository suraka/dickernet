import { createAction, union, props } from '@ngrx/store';
import { Ad } from './../../core/models';

export const searchSuccess = createAction(
  '[Books/AngularFirestore] Search Success',
  props<{ ads: Ad[] }>()
);

export const searchFailure = createAction(
  '[Books/AngularFirestore] Search Failure',
  props<{ errorMsg: string }>()
);

/**
 * Export a type alias of all actions in this action group
 * so that reducers can easily compose action types
 */
const all = union({ searchSuccess, searchFailure });
export type AdsFirestoreActionsUnion = typeof all;
