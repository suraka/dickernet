import { createAction, props } from '@ngrx/store';

export const searchAds = createAction(
  '[Find Ad Page] Search Ads',
  props<{ query: string }>()
);

export type FindAdPageActionsUnion = ReturnType<typeof searchAds>;
