import { createAction, props } from '@ngrx/store';
import { Ad } from './../../core/models';

export const loadAd = createAction(
    '[Ad  Exists Guard] Load Ad',
    props<{ ad: Ad }>()
);

export type AdActionsUnion = ReturnType<typeof loadAd>;