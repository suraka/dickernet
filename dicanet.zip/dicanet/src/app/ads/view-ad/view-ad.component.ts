import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import * as firebase from 'firebase/app';
import { MatSnackBar } from '@angular/material/snack-bar';
import { 
  MatBottomSheet, 
  MatBottomSheetRef, 
  MAT_BOTTOM_SHEET_DATA 
} from '@angular/material/bottom-sheet';

import { Observable, Subscription, interval } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { AuthService, AdService, ImageCompressionService, MessageService } from './../../core/services';
import { User, Ad, Message } from './../../core/models';
import { routerTransition } from './../../shared/animations';

@Component({
  selector: 'app-view-ad',
  templateUrl: './view-ad.component.html',
  styleUrls: ['./view-ad.component.scss'],
  animations: [routerTransition()]
})
export class ViewAdComponent implements OnInit, OnDestroy {

  private _aid: string;
  private _uid: string; // advertiser id
  public showPhone: boolean = false;
  public advertiser$: Observable<User>;
  public currentUser: User;
  public ad$: Observable<Ad>;
  public isAdmin: boolean = false;
  private _adminSubscription: Subscription;
  private _adSubscription: Subscription;
  private _filenames: string[] = new Array();
  private _fileUrls: string[] = new Array();
  private _compressedPhotoUrls: string[] = new Array();
  public isLoading: boolean = false;
  public isUploading: boolean = false;
  public isDeleting: boolean = false;
  public uploadProgress$: Observable<number>;
  private _taskSubscription: Subscription;
  private _downloadURLSubscription: Subscription;
  private _downloadCompressedSubscription: Subscription;
  private _deleteAdPictureSubscription: Subscription;
  public error: string;

  constructor(
    private _route: ActivatedRoute,
    private _location: Location,
    public afAuth: AngularFireAuth,
    public auth: AuthService,
    private _afs: AngularFirestore,
    private _storage: AngularFireStorage,
    private _ad: AdService,
    private _snackBar: MatSnackBar,
    private _bottomSheet: MatBottomSheet,
    private _imageCompressor: ImageCompressionService,
  ) { 
    // access admin status
    this._adminSubscription = afAuth.idTokenResult.subscribe((token: any) => {
      if (auth.isLoggedIn()) {
        if (token.claims.admin) {
          this.isAdmin = token.claims.admin;
        } else {
          this.isAdmin = false;
        }
        this.currentUser = this.afAuth.auth.currentUser;
      }
    }, (error) => console.log(error));

    // get ad id from the route
    this._aid = this._route.snapshot.paramMap.get('id');

    // access ad document in firestore
    const adDoc: AngularFirestoreDocument<Ad> = this._afs.doc<Ad>(`ads/${this._aid}`);
    this.ad$ = adDoc.valueChanges();

    // access advertiser document in firestore
    this._adSubscription = this.ad$.subscribe((ad) => {
      this._uid = ad.uid;
      this._filenames = ad.filenames;
      this._fileUrls = ad.fileUrls;
      this._compressedPhotoUrls = ad.compressedPhotoUrls;
      const advertiserDoc: AngularFirestoreDocument<User> = this._afs.doc<User>(`users/${ad.uid}`);
      this.advertiser$ = advertiserDoc.valueChanges();
    });
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    if (this._adminSubscription) {
      this._adminSubscription.unsubscribe();
    }

    if (this._adSubscription) {
      this._adSubscription.unsubscribe();
    }

    if (this._taskSubscription) {
      this._taskSubscription.unsubscribe();
    }

    if (this._downloadURLSubscription) {
      this._downloadURLSubscription.unsubscribe();
    }

    if (this._downloadCompressedSubscription) {
      this._downloadCompressedSubscription.unsubscribe();
    }
  }

  public togglePhone(phone: string) {
    if (this.showPhone) {
      this.showPhone = false;
      return this._snackBar.dismiss();
    }

    const title: string = 'Call';
    const message: string = phone;

    this.openSnackBar(message, title);

    this.showPhone = !this.showPhone;
  }
  
  // go back to previous location
  goBack() {
    this._location.back();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });

    if(this.showPhone) {
      interval(12000).pipe(
        map((x) => { 
          return this.showPhone = !this.showPhone;
         })
      );
      window.alert('Off Phone timer')
    }
  }

  async soldAd(uid: string, aid: string, sold: number, filenames: []) {
    this.isLoading = true;

    const data: Partial<User> = {
      uid,
      sold: sold + 1,
    };

    if (confirm('This product will be remove from the platform')) {
      try {
        await this.auth.updateUserDocument(data);
        this.deleteAd(uid, aid, filenames);
      } catch(error) {
        console.log(error.message);
        this.error = error.message;
      }
    }

    this.isLoading = false;
  }

  async publishOrBlockAd(aid: string, publish: boolean) {
    this.isLoading = true;

    const data: Ad = {
      aid,
      public: publish ? false : true,
    };

    if (confirm(publish ? 'Are you sure you want to block this ad?' : 'Are you sure you want to publish this ad?') === true) {
      try {
        await this._ad.updateAdDocument(data);

        const title = publish ? 'Block - Successful' : 'Publish - Successful';
        const msg = publish ? 'Ad is now block.' : 'Ad has now gone public.';

        this.openSnackBar(msg, title);
      } catch(error) {
        console.log(error.message);
        this.error = error.message;
      }
    }

    this.isLoading = false;
  }

  async deleteAd(uid: string, aid: string, filenames: []) {
    this.isLoading = true;

    if (confirm('Are you sure you want to delete this ad?') === true) {
      try {
        await this._ad.deleteAd(uid, aid, filenames);

        const title = 'Delete - Successful';
        const msg = 'Ad is now deleted from the platform.';

        this.openSnackBar(msg, title);
      } catch(error) {
        console.log(error.message);
        this.error = error.message;
      }
    }

    this.isLoading = false;
  }

  toggleAdReport(): void {
    this._bottomSheet.open(FeedbackBottomSheetComponent, {
      data: { 
        email: ['info.dickernet@gmail.com'], 
        info: 'We appreciate your time and our team will follow up on your feedback.'
      },
    });
  }

  public async fileChange(event) {
    // start uploading
    this.isUploading = true;

    // clear properties
    this.error = null;

    if (!event.target.files[0] || event.target.files[0].length === 0) {
      return this.error = 'You must upload at least one picture';
    }

    // add user id to file metadata
    const metadata = {
      customMetadata: {
        uid: this._uid,
      }
    };

    // get uploaded file
    const file = await this._imageCompressor.resizeImage(event.target.files[0], 520, 1);
    const compressedImage = await this._imageCompressor.resizeImage(file, 45, 0);
    console.log(`original size: ${event.target.files[0].size}, compress size 1: ${file.size} bytes, compress size 2: ${compressedImage.size} bytes`);

    // generate a random number to be use for picture name
    const timestamp = firebase.firestore.Timestamp.now().toMillis();
    const filename = this._randomIntFromInterval(20, 49) + timestamp;
    console.log(filename);

    // create original && compressed file reference
    const filePath = `users/${this._uid}/ads/${this._aid}/${filename}`;
    const compressedFilePath = `users/${this._uid}/ads/${this._aid}/compressed.${filename}`;
    const fileRef = this._storage.ref(filePath);
    const compressedFileRef = this._storage.ref(compressedFilePath);

    // upload and store both original && compressed
    const task = this._storage.upload(filePath, file, metadata);
    this._storage.upload(compressedFilePath, compressedImage);
    
    // check for errors in uploading
    task.catch(error => {
      console.log(`task: ${error.message}`);
      this.error = error.message;
    });

    // monitor uploading progress
    this.uploadProgress$ = task.percentageChanges();

    // get notified when the download url is available
    this._taskSubscription = task.snapshotChanges().pipe(finalize(() => {
      const downloadUrl = fileRef.getDownloadURL();
      const downloadCompressedUrl = compressedFileRef.getDownloadURL();
      this._downloadURLSubscription = downloadUrl.subscribe((photoUrl) => {
        this._downloadCompressedSubscription = downloadCompressedUrl.subscribe(async (compressedPhotoUrl) => {
          this._filenames.push(filename.toString());
          this._fileUrls.push(photoUrl);
          this._compressedPhotoUrls.push(compressedPhotoUrl);

          // prepare data to be added to firestore
          const data: Ad = {
            uid: this._uid,
            aid: this._aid,
            filenames: this._filenames,
            fileUrls: this._fileUrls,
            compressedPhotoUrls: this._compressedPhotoUrls,
            public: false,
            updated: firebase.firestore.Timestamp.now().toMillis()
          }

          await this._ad.updateAdDocument(data);
          console.log(`Upload was successful. You may upload more picture(s)`, 'Upload');
        });
      });
      this.isUploading = false;
    })).subscribe();
  }

  private _randomIntFromInterval(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  async deleteAdPicture(filename: string, i: number) {
    if (confirm('Are you sure you want to delete this picture?') === true) {
      this.isDeleting = true;

      // Create a reference to the file to delete
      const filePath = `users/${this._uid}/ads/${this._aid}/${filename}`;
      const compressedFilePath = `users/${this._uid}/ads/${this._aid}/compressed.${filename}`;
      
      this._filenames.splice(i, 1)
      this._fileUrls.splice(i, 1);
      this._compressedPhotoUrls.splice(i, 1);

      // prepare data to be added to firestore
      const data: Ad = {
        uid: this._uid,
        aid: this._aid,
        filenames: this._filenames,
        fileUrls: this._fileUrls,
        compressedPhotoUrls: this._compressedPhotoUrls
      }

      try {
        this._storage.ref(filePath).delete();
        this._storage.ref(compressedFilePath).delete();
        await this._ad.updateAdDocument(data);
        console.log(`Delete was successful. You may upload more picture(s)`, 'Delete Picture');
      } catch(error) { 
        console.log(error.message) ;
        this.error = error.message;
      }

      this.isDeleting = false;
    }
  }
}

@Component({
  selector: 'feedback',
  templateUrl: 'feedback.component.html',
})
export class FeedbackBottomSheetComponent implements OnInit {
  public isLinear = true;
  public feedbackFormGroup: FormGroup;
  public isLoading: boolean = false;
  public color: string = 'primary';
  public swap: boolean = false;
  public error: string;

  constructor(
    private _bottomSheetRef: MatBottomSheetRef<FeedbackBottomSheetComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private _afs: AngularFirestore,
    private _snackBar: MatSnackBar,
    private message: MessageService
  ) {}

  ngOnInit() {
    this.feedbackFormGroup = this._formBuilder.group({
      fullname: ['', Validators.required],
      address: ['', Validators.required],
      satisfied: [''],
      message: ['', Validators.required]
    });

    this.feedback.satisfied.setValue(true);
  }

  get feedback() { return this.feedbackFormGroup.controls; }

  closeBottomSheetFeedback(event: MouseEvent): void {
    this._bottomSheetRef.dismiss();
    //event.preventDefault();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onSubmitFeedback(event: MouseEvent) {
    this.isLoading = true;

    // create document reference, id
    const mid = this._afs.createId();

    // access feedback form data
    const { fullname, address, satisfied, message } = this.feedbackFormGroup.value;

    const data: Message = {
      mid,
      fullname,
      address,
      satisfied,
      message,
      type: 'feedback',
      seen: false,
      created: firebase.firestore.Timestamp.now().toMillis()
    }

    const title = 'Feedback';
    const msg = `Your feedback was sent to ${this.data.email} successfully.`;

    try {
      await this.message.createMessageDocument(data);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
    this.closeBottomSheetFeedback(event);
    this.openSnackBar(msg, title);
  }
}