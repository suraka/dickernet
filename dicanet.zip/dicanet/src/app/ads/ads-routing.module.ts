import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { 
  AngularFireAuthGuard,
  customClaims,
  redirectUnauthorizedTo, 
 } from '@angular/fire/auth-guard';
 import { pipe } from 'rxjs';
 import { map } from 'rxjs/operators';

import { PostAdComponent } from './post-ad/post-ad.component';
import { ViewAdComponent } from './view-ad/view-ad.component';
import { EditAdComponent } from './edit-ad/edit-ad.component';

const redirectUnauthorizedToLogin = () => redirectUnauthorizedTo(['/auth/login']);
const onlyAllowSelfOrAdmin = (next) => pipe(
  customClaims,
  map(claims => {
    if (claims.length === 0) {
      return [''];
    }

    return next.params.id === claims.user_id || claims.admin;
  })
);

const routes: Routes = [
  {
    path: 'post-ad',
    component: PostAdComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: redirectUnauthorizedToLogin }
  },
  {
    path: 'view-ad/:id',
    component: ViewAdComponent
  },
  {
    path: 'edit-ad/:id/:aid',
    component: EditAdComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: onlyAllowSelfOrAdmin }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdsRoutingModule { }
