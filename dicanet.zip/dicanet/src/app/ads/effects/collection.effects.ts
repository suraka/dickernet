import { Injectable } from "@angular/core";
import { Actions, Effect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";
import { defer, Observable, of } from "rxjs";
import { catchError, map, mergeMap, switchMap, toArray } from "rxjs/operators";
import {
  CollectionPageActions,
  FirestoreCollectionActions,
  SelectedAdPageActions
} from "../actions";

import { AngularFirestore } from "@angular/fire/firestore";

import { Ad } from "./../../core/models";

/* @Injectable()
export class CollectionEffects {
  constructor(
    private actions$: Actions<SelectedAdPageActions.SelectedAdPageActionsUnion>,
    private readonly _afs: AngularFirestore
  ) {}

  @Effect()
  loadCollection$: Observable<Action> = this.actions$.pipe(
    ofType(CollectionPageActions.loadCollection.type),
    switchMap(() =>
      this._afs
        .collection<Ad>("ads")
        .valueChanges()
        .pipe(
          //toArray(),
          map((ads: Ad[]) => FirestoreCollectionActions.loadAdsSuccess({ ads })),
          catchError(error =>
            of(FirestoreCollectionActions.loadAdsFailure({ error }))
          )
        )
    )
  );

  @Effect()
  postAdToCollection$: Observable<Action> = this.actions$.pipe(
    ofType(SelectedAdPageActions.addAd.type),
    mergeMap(({ ad }) =>
    this._afs.doc<Ad>(`ads/${ad.aid}`).set(ad).pipe(
        map(() => FirestoreCollectionActions.postAdSuccess({ ad })),
        catchError(() => of(FirestoreCollectionActions.postAdFailure({ ad })))
      )
    )
  );

  @Effect()
  removeBookFromCollection$: Observable<Action> = this.actions$.pipe(
    ofType(SelectedBookPageActions.removeBook.type),
    mergeMap(({ book }) =>
      this.db.executeWrite('books', 'delete', [book.id]).pipe(
        map(() => CollectionApiActions.removeBookSuccess({ book })),
        catchError(() => of(CollectionApiActions.removeBookFailure({ book })))
      )
    )
  );
}
 */