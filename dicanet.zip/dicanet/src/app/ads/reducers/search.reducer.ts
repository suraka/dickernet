import { AdsFirestoreActions, FindAdPageActions } from './../actions';

export interface State {
  ids: string[];
  loading: boolean;
  error: string;
  query: string;
}

const initialState: State = {
  ids: [],
  loading: false,
  error: '',
  query: '',
};

export function reducer(
  state = initialState,
  action:
    | AdsFirestoreActions.AdsFirestoreActionsUnion
    | FindAdPageActions.FindAdPageActionsUnion
): State {
  switch (action.type) {
    case FindAdPageActions.searchAds.type: {
      const query = action.query;

      if (query === '') {
        return {
          ids: [],
          loading: false,
          error: '',
          query,
        };
      }

      return {
        ...state,
        loading: true,
        error: '',
        query,
      };
    }

    case AdsFirestoreActions.searchSuccess.type: {
      return {
        ids: action.ads.map(ad => ad.aid),
        loading: false,
        error: '',
        query: state.query,
      };
    }

    case AdsFirestoreActions.searchFailure.type: {
      return {
        ...state,
        loading: false,
        error: action.errorMsg,
      };
    }

    default: {
      return state;
    }
  }
}

export const getIds = (state: State) => state.ids;

export const getQuery = (state: State) => state.query;

export const getLoading = (state: State) => state.loading;

export const getError = (state: State) => state.error;
