import {
    SelectedAdPageActions,
    CollectionPageActions,
    FirestoreCollectionActions,
  } from './../actions';
  
  export interface State {
    loaded: boolean;
    loading: boolean;
    ids: string[];
  }
  
  const initialState: State = {
    loaded: false,
    loading: false,
    ids: [],
  };
  
  export function reducer(
    state = initialState,
    action:
      | SelectedAdPageActions.SelectedAdPageActionsUnion
      | CollectionPageActions.CollectionPageActionsUnion
      | FirestoreCollectionActions.FirestoreCollectionActionsUnion
  ): State {
    switch (action.type) {
      case CollectionPageActions.loadCollection.type: {
        return {
          ...state,
          loading: true,
        };
      }
  
      case FirestoreCollectionActions.loadAdsSuccess.type: {
        return {
          loaded: true,
          loading: false,
          ids: action.ads.map(ad => ad.aid),
        };
      }
  
      case FirestoreCollectionActions.postAdSuccess.type:
      case FirestoreCollectionActions.removeAdFailure.type: {
        if (state.ids.indexOf(action.ad.aid) > -1) {
          return state;
        }
  
        return {
          ...state,
          ids: [...state.ids, action.ad.aid],
        };
      }
  
      case FirestoreCollectionActions.removeAdSuccess.type:
      case FirestoreCollectionActions.postAdFailure.type: {
        return {
          ...state,
          ids: state.ids.filter(id => id !== action.ad.aid),
        };
      }
  
      default: {
        return state;
      }
    }
  }
  
  export const getLoaded = (state: State) => state.loaded;
  
  export const getLoading = (state: State) => state.loading;
  
  export const getIds = (state: State) => state.ids;
  