import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';

import * as firebase from 'firebase/app';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { AuthService, AdService, KeywordsService, ImageCompressionService } from './../../core/services';
import { Ad, Picture } from './../../core/models';
import { 
  TYPES, CATEGORIES, PROPERTIES, SERVICES, ELECTRONICS, TECHNOLOGY, FURNITURES, AUTOMOBILES, 
  BODY, CARS, TRICYCLES, TRUCKVANBUS, HEAVYDUTY, REGIONS, TRANSMISSION, FUEL, ENGINE
} from './../../core/constants.data';

import { routerTransition } from './../../shared/animations';
import * as utility from './../../core/utility';

@Component({
  selector: 'app-post-ad',
  templateUrl: './post-ad.component.html',
  styleUrls: ['./post-ad.component.scss'],
  animations: [routerTransition()],
})
export class PostAdComponent implements OnInit, OnDestroy {

  public isLinear = true; // allow user to move next after required fields are completed
  public introAdForm: FormGroup;
  public detailsAdForm: FormGroup;
  public contactAdForm: FormGroup;
  public miscInfoAdForm: FormGroup;
  public uploadPicturesAdForm: FormGroup;
  public types = TYPES;
  public regions = REGIONS;
  public categories = CATEGORIES;
  public properties = PROPERTIES;
  public services = SERVICES;
  public electronics = ELECTRONICS;
  public technology = TECHNOLOGY;
  public furnitures = FURNITURES;
  public automobiles = AUTOMOBILES;
  public bodyTypes = BODY;
  public transmissions = TRANSMISSION;
  public fuels = FUEL;
  public engines = ENGINE;
  public cars = CARS;
  public tricycles = TRICYCLES;
  public trucks = TRUCKVANBUS;
  public heavyDuties = HEAVYDUTY;

  private _uid: string;
  private _docRef: string;
  public downloadUrl$: Observable<string>;
  public uploadProgress$: Observable<number>;
  public pictures: Picture[] = new Array();
  public isLoading: boolean = false;
  public color: string = 'primary';
  public swap: boolean = false;
  public action: 'login' | 'signup' = 'login'; // action property default to login
  public error: string;
  private _downloadURLSubscription: Subscription;
  private _downloadCompressedSubscription: Subscription;
  private _taskSubscription: Subscription;
  private _deleteAdPictureSubscription: Subscription;

  constructor(
    private _location: Location,
    private _formBuilder: FormBuilder,
    private _router: Router,
    private _afAuth: AngularFireAuth,
    private _afs: AngularFirestore,
    private _storage: AngularFireStorage,
    public auth: AuthService,
    public ad: AdService,
    private _keywords: KeywordsService,
    private _imageCompressor: ImageCompressionService,
    private _snackBar: MatSnackBar
  ) {
    // access user id
    this._uid =  this._afAuth.auth.currentUser.uid;

    // create document reference id
    this._docRef = this._afs.createId();
  }

  ngOnInit() {
    this.introAdForm = this._formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required]
    });

    this.detailsAdForm = this._formBuilder.group({
      type: ['', Validators.required],
      category: ['', Validators.required],
      subcategory: [''], // <--- for vehicles|automobiles, services, properties, furnitures, electronics 
      brand: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      model: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      year: [''], // <--- for computers, mobile phones, sound systems, tablets, tv, cars, heavy duty, tricycle motors, trucks vans buses
      color: [''], // <--- for all categories
      mileage: [''], // <--- for cars, heavy duty, tricycle motors, trucks vans buses
      transmission: [''], // e.g.: automatic or manuel <--- for cars, heavy duty, tricycle motors, trucks vans buses
      fuel: [''], // e.g.: electric, petrol, diesel or gas <--- for cars, heavy duty, tricycle motors, trucks vans buses
      engine: [''], // e.g.: four cylinder <--- for cars, heavy duty, tricycle motors, trucks vans buses
      body: [''], // e.g.: saloon <--- for cars, heavy duty, tricycle motors, trucks vans buses
      price: ['', Validators.required]
    });

    this.miscInfoAdForm = this._formBuilder.group({
      status: [''],
      negotiable: [''],
      swapping: ['']
    });

    this.contactAdForm = this._formBuilder.group({
      phone: ['', Validators.required],
      address: this._formBuilder.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        region: ['', Validators.required]
      })
    });

    this.miscInfoAdForm.setValue({status: false, negotiable: true, swapping: false});

    this.uploadPicturesAdForm = this._formBuilder.group({
      files: ['']
    });
  }

  ngOnDestroy() {
    if (this._downloadURLSubscription) {
      this._downloadURLSubscription.unsubscribe();
    }

    if (this._taskSubscription) {
      this._taskSubscription.unsubscribe();
    }

    if (this._downloadCompressedSubscription) {
      this._downloadCompressedSubscription.unsubscribe();
    }

    if(this._deleteAdPictureSubscription) {
      this._deleteAdPictureSubscription.unsubscribe();
    }
  }

  // go back to previous location
  goBack() {
    this._location.back();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  // access to form fields
  get details() { return this.detailsAdForm.controls; }

  // process data and add it to firestore as an ad
  async onSubmitPostAdForm() {
    this.isLoading = true;
    this.error = null;

    if (this.introAdForm.invalid || this.detailsAdForm.invalid || this.miscInfoAdForm.invalid || this.contactAdForm.invalid) {
      return this.error = 'Ad could not be submitted';
    }

    const filenames = new Array();
    const fileUrls = new Array();
    const compressedPhotoUrls = new Array();

    Array.from(this.pictures).forEach((picture: Picture) => {
      filenames.push(picture.filename);
      fileUrls.push(picture.fileUrl);
      compressedPhotoUrls.push(picture.compressedPhotoUrl);
    });

    // access form fields
    const { title, description } = this.introAdForm.value;
    const { type, category, subcategory, brand, model, year, color, mileage, transmission, fuel, engine, body, price } = this.detailsAdForm.value;
    const { status, negotiable, swapping } = this.miscInfoAdForm.value;
    const { phone, address } = this.contactAdForm.value;

    // generate keywords
    const keywords = this._keywords.generateKeywords(utility.toLowerCase(title));

    // prepare data to be added to firestore
    const data: Ad = {
      uid: this._uid,
      aid: this._docRef,
      title: utility.toLowerCase(title), 
      description: utility.toLowerCase(description), 
      type, category, price,
      status, negotiable, swapping, 
      phone, 
      address: { 
        street: address.street, 
        city: address.city, 
        region: address.region 
      },
      filenames,
      fileUrls,
      compressedPhotoUrls,
      color: color ? color : null, 
      subcategory: subcategory ? subcategory : null, 
      brand: brand ? brand : null, 
      model: model ? model : null,  
      year: year ? year : null,  
      mileage: mileage ? mileage : null, 
      transmission: transmission ? transmission : null, 
      fuel: fuel ? fuel : null, 
      engine: engine ? engine : null, 
      body: body ? body : null,
      public: false,
      views: 0,
      keywords,
      created: firebase.firestore.Timestamp.now().toMillis()
    };
    
    try {
      // create firestore document with the prepared data
      await this.ad.createAdDocument(data);

      // reset all form fields
      this.introAdForm.reset();
      this.detailsAdForm.reset();
      this.miscInfoAdForm.reset();
      this.contactAdForm.reset();
      this.uploadPicturesAdForm.reset();

      // prepare a message
      const title = 'Post Ad';
      const msg = 'Ad was posted successful.';

      // navigate to user profile
      this._router.navigate(['/users/profile', this._uid]);

      // alert the user with the prepared message after successful posting the ad
      this.openSnackBar(msg, title);
    } catch(error) { 
      console.log(error.message) ;
      this.error = error.message;
    }

    this.isLoading = false;
  }

  public async fileChange(event) {
    // start uploading
    this.isLoading = true;

    // clear properties
    this.downloadUrl$ = null;
    this.error = null;

    if (!event.target.files[0] || event.target.files[0].length === 0) {
      return this.error = 'You must upload at least one picture';
    }

    // add user id to file metadata
    const metadata = {
      customMetadata: {
        uid: this._uid,
      }
    };

    // get uploaded file
    const file = await this._imageCompressor.resizeImage(event.target.files[0], 520, 1);
    const compressedImage = await this._imageCompressor.resizeImage(file, 45, 0);
    //console.log(`original size: ${event.target.files[0].size}, compress size 1: ${file.size} bytes, compress size 2: ${compressedImage.size} bytes`);

    // generate a random number to be use for picture name
    const timestamp = firebase.firestore.Timestamp.now().toMillis();
    const filename = this._randomIntFromInterval(20, 49) + timestamp;

    // create original && compressed file reference
    const filePath = `users/${this._uid}/ads/${this._docRef}/${filename}`;
    const compressedFilePath = `users/${this._uid}/ads/${this._docRef}/compressed.${filename}`;
    const fileRef = this._storage.ref(filePath);
    const compressedFileRef = this._storage.ref(compressedFilePath);

    // upload and store both original && compressed
    const task = this._storage.upload(filePath, file, metadata);
    this._storage.upload(compressedFilePath, compressedImage);
    
    // check for errors in uploading
    task.catch(error => {
      console.log(`task original: ${error.message}`);
      this.error = error.message;
    });

    // monitor uploading progress
    this.uploadProgress$ = task.percentageChanges();

    // get notified when the download url is available
    this._taskSubscription = task.snapshotChanges().pipe(finalize(() => {
      this.downloadUrl$ = fileRef.getDownloadURL();
      const downloadCompressedUrl = compressedFileRef.getDownloadURL();
      this._downloadURLSubscription = this.downloadUrl$.subscribe((photoUrl) => {
        this._downloadCompressedSubscription = downloadCompressedUrl.subscribe((compressedPhotoUrl) => {
          this.pictures.push({
            filename: filename.toString(),
            fileUrl: photoUrl, 
            compressedPhotoUrl: compressedPhotoUrl
          });
        });
      });
      this.isLoading = false;
    })).subscribe();
  }

  private _randomIntFromInterval(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  deleteAdPicture(filename: string, i: number) {
    if (confirm('Are you sure you want to delete this picture?') === true) {
      // Create a reference to the file to delete
      const filePath = `users/${this._uid}/ads/${this._docRef}/${filename}`;
      const compressedFilePath = `users/${this._uid}/ads/${this._docRef}/compressed.${filename}`;
      const fileRef = this._storage.ref(filePath);
      const compressedFileRef = this._storage.ref(compressedFilePath);
      this._deleteAdPictureSubscription = fileRef.delete().subscribe(() => {
        compressedFileRef.delete();
        this.pictures.splice(i, 1);
        console.log(`Delete was successful. You may upload ${3 - this.pictures.length} more picture(s)`, 'Delete Picture');
      });
    }
  }

}
