import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import { AngularFireAuth } from '@angular/fire/auth';

import { AuthService } from './../core/services';

declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {

  public showSidebar = false;
  public isAdmin: boolean = false;
  private _authTokenSubscription: Subscription;

  constructor(
    public afAuth: AngularFireAuth,
    public auth: AuthService,
  ) {
    this._authTokenSubscription = afAuth.idTokenResult.subscribe((token: any) => {
      if (auth.isLoggedIn()) {
        if (token.claims.admin) {
          this.isAdmin = token.claims.admin;
        } else {
          this.isAdmin = false;
        }
      }
    }, (error) => console.log(error));
  }

  ngOnInit() {    
    /* $(document).ready(() => {
      $('#sidebarCollapse').on('click', () => {
        $('#sidebar').addClass('active');
        $('.overlay').addClass('active');
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');
      });
      $('#dismiss, .overlay').on('click', () => {
        $('#sidebar').removeClass('active');
        $('.overlay').removeClass('active');
      });
    }); */
  }

  ngOnDestroy() {
    if (this._authTokenSubscription) {
      this._authTokenSubscription.unsubscribe();
    }
  }

  public toggleSidebar() {
    this.showSidebar = !this.showSidebar;
  }

  disimiss() {
    $(document).ready(() => {
      $('#sidebar').removeClass('active');
      $('.overlay').removeClass('active');
    });
  }

}
