export interface Message {
    mid?: string;
    aid?: string;
    fullname?: string;
    address?: string;
    email?: string;
    phone?: string;
    satisfied?: boolean;
    message?: string;
    type?: string; // contact || feedback 
    seen?: boolean;
    created?: any;
}