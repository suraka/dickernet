// Chats contains only meta info about each member conversation
// stored under the chats's unique ID
export interface Chat {
    cid?: string; // chats's unique ID
    lastMessage?: string;
    timestamp?: number;
}

// Conversation members are easily accessible
// and stored by a user unique ID
// NB: Enteries for this interface will be both currentUser & otherUser
// i.e.: members->uid for currentUser
// i.e.: members->uid for otherUser
// i.e.: members->uid->uid for currentUser
// i.e.: members->uid->uid for otherUser
export interface Members {
    key?: string;
    uid?: string; // unique ID of reciever or sender
    cid?: string;
    displayName?: string,
    phone?: string,
    email?: string,
    photoUrl?: string;
    compressedPhotoUrl?: string;
}

// Messages are separate from data we may want to iterate quickly
// but still easily paginated and queried, and organized by chat
// conversation ID
// i.e.: messages->cid-mid
export interface Messages {
    mid?: string; // message's unique ID
    cid?: string; // chats's unique ID
    from?: string; // unique ID of sender
    to?: string; // unique ID of reciever
    message?: {
        text?: string;
        photoUrl?: string;
        compressedPhotoUrl?: string;
    };
    filename?: string;
    type?: string; // file || text || emoji 
    seen?: boolean;
    timestamp?: number;
}