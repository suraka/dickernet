export interface Ad {
    aid?: string;
    uid?: string;
    keywords?: string[]; // store possible search terms 
    title?: string;
    description?: string;
    type?: string;
    price?: number;
    category?: string;
    subcategory?: string;
    brand?: string; // car brand
    model?: string; // car model
    color?: string; // color of vehicle
    year?: string; // car model year
    trim?: string; // trim or edition
    mileage?: string; // in kilometers - km
    transmission?: string; // automatic or manual
    fuel?: string; // diesel, electric, gas or petrol
    engine?: string; // engine capacity in horse power - hp or litres
    body?: string; // 4x4, suv, saloon, estate, hatchback, sports, mpv, convertible
    status?: boolean; // used or new
    swapping?: boolean;
    negotiable?: boolean;
    fileUrls?: string[];
    filenames?: string[];
    compressedPhotoUrls?: string[];
    views?: number;
    address?: {
        street?: string; // e.g.: american hse, east legon
        city?: string; // e.g.: accra
        region?: string; // e.g.: northern region
    };
    public?: boolean;
    town?: string;
    escrow?: boolean;
    phone?: string;
    time?: number;
    expire?: number;
    rating?: number;
    reviews?: number; // Array<string>
    created?: number;
    updated?: number;
}