export interface Settings {
    id?: string;
    businessName?: string;
    businessLogo?: string;
    phone?: string[];
    address?: {
        street?: string;
        city?: string;
        region?: string;
    };
    about?: {
        title?: string;
        message?: string;
    };
    allowPostAd?: {
        emailVerified?: boolean; // allow users with verified email addresses
    }; 
    allowLogin?: {
        emailVerified?: boolean; // allow users with verified email addresses
    }; 
}