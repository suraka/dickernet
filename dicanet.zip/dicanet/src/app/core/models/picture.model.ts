export class Picture {
    filename?: string;
    fileUrl?: string;
    compressedPhotoUrl?: string;
}