export interface User {
    uid: string;
    keywords?: string[]; // store possible search terms 
    displayName?: string;
    email?: string;
    emailVerified?: boolean;
    phone?: string;
    address?: {
        street?: string; // e.g.: american hse, east legon
        city?: string; // e.g.: accra
        region?: string; // e.g.: northern region
    };
    photoUrl?: string;
    compressedPhotoUrl?: string;
    ads?: number; // total ads posted
    sold?: number; // number of products sold
    block?: {
        incomplete?: boolean; // signup not completed
        restrain?: boolean; // admin limiting user access control
    },
    created?: number;
}
