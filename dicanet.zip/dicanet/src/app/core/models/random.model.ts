export interface Chance {
    id?: string;
    isGoTime: boolean;
    timestamp: number;
}