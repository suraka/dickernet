export interface Item {
    value: string;
    viewValue: string;
  }