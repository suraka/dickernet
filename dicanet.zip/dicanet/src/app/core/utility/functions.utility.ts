/**
 * convert to lowercase
 * @param str
 */
export function toLowerCase(str: string): string {
    return str.toLocaleLowerCase();
}

/**
 * make a random choice
 * @param min
 * @param max
 */
export function randomChoice(min: number, max: number): boolean {
    const randomChoiceIndex = Math.floor(Math.random() * (max - min + 1) + min);
    return randomChoiceIndex > max/2 ? true : false;
}

/**
 * make a random choice
 * @param min
 * @param max
 */
export function randomIntFromInterval(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}