import { Item }  from './models';

export const TYPES: Item[] = [
    {value: 'both', viewValue: 'Cash/Swap'}, 
    {value: 'cash', viewValue: 'Cash'}, 
    {value: 'swap', viewValue: 'Swap'}
];

export const TRANSMISSION: Item[] = [
    {value: 'auto', viewValue: 'Automatic'}, 
    {value: 'manual', viewValue: 'Manual'}
];

export const FUEL: Item[] = [
    {value: 'electric', viewValue: 'electric'}, 
    {value: 'petrol', viewValue: 'Petrol'}, 
    {value: 'diesel', viewValue: 'Diesel'},
    {value: 'gas', viewValue: 'Gas'}
];

export const ENGINE: Item[] = [
    {value: 'twin', viewValue: 'Twin Cylinder'}, 
    {value: 'three', viewValue: 'Three Cylinder'}, 
    {value: 'four', viewValue: 'Four Cylinder'},
    {value: 'five', viewValue: 'Five Cylinder'}, 
    {value: 'six', viewValue: 'Six Cylinder'}, 
    {value: 'seven', viewValue: 'Seven Cylinder'},
    {value: 'eight', viewValue: 'Eight Cylinder'},
    {value: 'nine', viewValue: 'Nine Cylinder'},
    {value: 'ten', viewValue: 'Ten Cylinder'},
    {value: 'others', viewValue: 'Others'}
];

export const REGIONS: Item[] = [
    {value: 'ahafo', viewValue: 'Ahafo Region'},
    {value: 'ashanti', viewValue: 'Ashanti Region'},
    {value: 'bono east', viewValue: 'bono East Region'},
    {value: 'brong-ahafo', viewValue: 'Brong-Ahafo Region'},
    {value: 'central', viewValue: 'Central Region'},
    {value: 'eastern', viewValue: 'Eastern Region'},
    {value: 'greater accra', viewValue: 'Greater Accra Region'},
    {value: 'northern', viewValue: 'Northern Region'},
    {value: 'north east', viewValue: 'North East Region'},
    {value: 'savannah', viewValue: 'Savannah Region'},
    {value: 'oti', viewValue: 'Oti Region'},
    {value: 'upper east', viewValue: 'Upper East Region'},
    {value: 'upper west', viewValue: 'Upper West Region'},
    {value: 'volta', viewValue: 'Volta Region'},
    {value: 'western north', viewValue: 'Western North Region'},
    {value: 'western', viewValue: 'Western Region'}
];

export const CATEGORIES: Item[] = [
    {value: 'agriculture', viewValue: 'Agriculture'},
    {value: 'businesses', viewValue: 'Businesses'},
    {value: 'clothing', viewValue: 'Clothing'},
    {value: 'education', viewValue: 'Education'},
    {value: 'electronics', viewValue: 'Electronics'},
    {value: 'equipments & tools', viewValue: 'Equipments & Tools'},
    {value: 'food', viewValue: 'Food'},
    {value: 'furnitures', viewValue: 'Furnitures'},
    {value: 'health', viewValue: 'Health'},
    {value: 'properties', viewValue: 'Properties'},
    {value: 'services', viewValue: 'Services'},
    {value: 'automobiles', viewValue: 'Vehicles'},
    {value: 'others', viewValue: 'Others'}
];

export const PROPERTIES: Item[] = [
    {value: 'land', viewValue: 'Land'},
    {value: 'house', viewValue: 'House'},
    {value: 'others', viewValue: 'Others'}
];

export const SERVICES: Item[] = [
    {value: 'building', viewValue: 'Building'},
    {value: 'construction', viewValue: 'Construction'},
    {value: 'carpentry', viewValue: 'Carpentry Works'},
    {value: 'distribution', viewValue: 'Distributions'},
    {value: 'laundry', viewValue: 'Laundry'},
    {value: 'painting', viewValue: 'Painting'},
    {value: 'printing', viewValue: 'Printing'},
    {value: 'stationeries', viewValue: 'Stationeries'},
    {value: 'renting', viewValue: 'Renting'},
    {value: 'teaching', viewValue: 'Teaching'},
    {value: 'others', viewValue: 'Other'}
];

export const ELECTRONICS: Item[] = [
    {value: 'computers', viewValue: 'Computers'},
    {value: 'accessories', viewValue: 'Accessories'},
    {value: 'decoders', viewValue: 'decoders'},
    {value: 'refrigerator', viewValue: 'fridge & defreezer'},
    {value: 'appliances', viewValue: 'home appliances'},
    {value: 'phones', viewValue: 'mobile phones'},
    {value: 'sound devices', viewValue: 'sound systems'},
    {value: 'tablets', viewValue: 'tablets'},
    {value: 'tv', viewValue: 'tv'},
    {value: 'others', viewValue: 'others'}
];

export const TECHNOLOGY: Item[] = [
    {value: 'akai', viewValue: 'akai'},
    {value: 'apple', viewValue: 'apple'},
    {value: 'dell', viewValue: 'dell'},
    {value: 'chico', viewValue: 'chico'},
    {value: 'hitachi', viewValue: 'hitachi'},
    {value: 'hp', viewValue: 'hp'},
    {value: 'htc', viewValue: 'htc'},
    {value: 'ignis', viewValue: 'ignis'},
    {value: 'infinix', viewValue: 'infinix'},
    {value: 'itel', viewValue: 'itel'},
    {value: 'nasco', viewValue: 'nasco'},
    {value: 'microsoft', viewValue: 'microsoft'},
    {value: 'panasonic', viewValue: 'panasonic'},
    {value: 'russell hobbs', viewValue: 'russell hobbs'},
    {value: 'samsung', viewValue: 'samsung'},
    {value: 'sony', viewValue: 'sony'},
    {value: 'tcl', viewValue: 'tcl'},
    {value: 'tecno', viewValue: 'tecno'},
    {value: 'toshiba', viewValue: 'toshiba'},
    {value: 'others', viewValue: 'others'}
];

export const FURNITURES: Item[] = [
    {value: 'center-table', viewValue: 'center table'},
    {value: 'dinning-table', viewValue: 'dinning table'},
    {value: 'cabinets', viewValue: 'kitchen cabinets'},
    {value: 'furniture', viewValue: 'office furniture'},
    {value: 'sofa', viewValue: 'sofa'},
    {value: 'tv', viewValue: 'tv stands'},
    {value: 'wardrobe', viewValue: 'wardrobe'},
    {value: 'others', viewValue: 'others'}
];

export const AUTOMOBILES: Item[] = [
    {value: 'auto-accessories', viewValue: 'Auto Accessories'},
    {value: 'bicycles', viewValue: 'Bicycles'},
    {value: 'cars', viewValue: 'Cars'},
    {value: 'heavy-duty', viewValue: 'Heavy-Duty'},
    {value: 'scooters', viewValue: 'Scooters'},
    {value: 'tractors', viewValue: 'Tractors'},
    {value: 'tricycles', viewValue: 'Tricycle Motors'},
    {value: 'trucks', viewValue: 'Trucks, Vans & Buses'},
    {value: 'others', viewValue: 'Others'}
];

export const BODY: Item[] =[
    {value: 'saloon', viewValue: 'Saloon'},
    {value: 'sedan', viewValue: 'Sedan'},
    {value: '4x4', viewValue: '4x4'},
    {value: 'hatchback', viewValue: 'Hatchback'},
    {value: 'suv', viewValue: 'SUV'},
    {value: 'crossover', viewValue: 'Crossover'},
    {value: 'Coupe', viewValue: 'Coupe'},
    {value: 'Convertible', viewValue: 'Convertible'},
    {value: 'others', viewValue: 'Others'},
];

export const CARS: Item[] = [
    {value: 'acura', viewValue: 'acura'},
    {value: 'albion', viewValue: 'albion'},
    {value: 'audi', viewValue: 'audi'},
    {value: 'austin', viewValue: 'austin'},
    {value: 'bentley', viewValue: 'bentley'},
    {value: 'berkeley', viewValue: 'berkeley'},
    {value: 'bugatti', viewValue: 'bugatti'},
    {value: 'cadillac', viewValue: 'cadillac'},
    {value: 'chevrolet', viewValue: 'chevrolet'},
    {value: 'chrysler', viewValue: 'chrysler'},
    {value: 'ahafo', viewValue: 'daewoo'},
    {value: 'dodge', viewValue: 'dodge'},
    {value: 'ferrari', viewValue: 'ferrari'},
    {value: 'fiat', viewValue: 'fiat'},
    {value: 'ford', viewValue: 'ford'},
    {value: 'gmc', viewValue: 'GMC'},
    {value: 'honda', viewValue: 'honda'},
    {value: 'hummer', viewValue: 'hummer'},
    {value: 'hyundai', viewValue: 'hyundai'},
    {value: 'infiniti', viewValue: 'infiniti'},
    {value: 'jaguar', viewValue: 'jaguar'},
    {value: 'jeep', viewValue: 'jeep'},
    {value: 'ahafo', viewValue: 'kia'},
    {value: 'land-rover', viewValue: 'land rover'},
    {value: 'lexington', viewValue: 'lexington'},
    {value: 'lexus', viewValue: 'lexus'},
    {value: 'lincoln', viewValue: 'lincoln'},
    {value: 'nissan', viewValue: 'nissan'},
    {value: 'mazda', viewValue: 'mazda'},
    {value: 'mercury', viewValue: 'mercury'},
    {value: 'mitsubishi', viewValue: 'mitsubishi'},
    {value: 'opel', viewValue: 'opel'},
    {value: 'renault', viewValue: 'renault'},
    {value: 'rolls-royce', viewValue: 'rolls-royce'},
    {value: 'suzuki', viewValue: 'suzuki'},
    {value: 'tesla', viewValue: 'tesla'},
    {value: 'toyota', viewValue: 'toyota'},
    {value: 'tractors', viewValue: 'tractors'},
    {value: 'kantanka', viewValue: 'kantanka'},
    {value: 'lamborghini', viewValue: 'lamborghini'},
    {value: 'volvo', viewValue: 'volvo'},
    {value: 'yamaha', viewValue: 'yamaha'},
    {value: 'others', viewValue: 'others'}
];

export const TRICYCLES: Item[] = [
    {value: 'motor-king', viewValue: 'motor king'},
    {value: 'yellow', viewValue: 'yellow yellow'},
    {value: 'others', viewValue: 'others'}
];

export const TRUCKVANBUS: Item[] = [
    {value: 'albion', viewValue: 'albion'},
    {value: 'ayats', viewValue: 'ayats'},
    {value: 'daewoo', viewValue: 'daewoo'},
    {value: 'fiat', viewValue: 'fiat'},
    {value: 'ford', viewValue: 'ford'},
    {value: 'hyundai', viewValue: 'hyundai'},
    {value: 'isuzu', viewValue: 'isuzu'},
    {value: 'karosa', viewValue: 'karosa'},
    {value: 'kia', viewValue: 'kia'},
    {value: 'leyland', viewValue: 'leyland'},
    {value: 'man truck', viewValue: 'man truck'},
    {value: 'mercedes benz', viewValue: 'mercedes benz'},
    {value: 'mitsubishi', viewValue: 'mitsubishi'},
    {value: 'neoplan', viewValue: 'neoplan'},
    {value: 'nissan', viewValue: 'nissan'},
    {value: 'renault', viewValue: 'renault'},
    {value: 'suzuki', viewValue: 'suzuki'},
    {value: 'tacuma', viewValue: 'tacuma'},
    {value: 'tata', viewValue: 'tata'},
    {value: 'tedom', viewValue: 'tedom'},
    {value: 'toyota', viewValue: 'toyota'},
    {value: 'van hool', viewValue: 'van hool'},
    {value: 'volgren', viewValue: 'volgren'},
    {value: 'volvo', viewValue: 'volvo'},
    {value: 'youngman', viewValue: 'youngman'},
    {value: 'yutong', viewValue: 'yutong'},
    {value: 'others', viewValue: 'others'}
];

export const HEAVYDUTY: Item[] = [
    {value: 'caterpiller', viewValue: 'caterpiller'},
    {value: 'gomaco', viewValue: 'gomaco'},
    {value: 'hitachi', viewValue: 'hitachi'},
    {value: 'volvo', viewValue: 'volvo'},
    {value: 'others', viewValue: 'others'}
];
