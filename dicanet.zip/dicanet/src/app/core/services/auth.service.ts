import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireDatabase } from '@angular/fire/database';

import * as firebase from 'firebase/app';
import * as admin from 'firebase-admin';

import { KeywordsService } from './keywords.service';
import { User } from './../models';
import * as utility from './../../core/utility';

/* const serviceAccount = require('./../../../../dickernet-30e8e-firebase-adminsdk-qbx01-497d65e650.json');

const defaultApp = admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://dickernet-30e8e.firebaseio.com'
});
 */
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private _router: Router,
    private _afAuth: AngularFireAuth,
    private _afs: AngularFirestore,
    private _afRDb: AngularFireDatabase,
    private _keywords: KeywordsService,
  ) {
  }

  // check user logged in status
  public isLoggedIn() {
    return !!this._afAuth.auth.currentUser;
  }

  // add user to firestore after signup
  public createUserDocument() {
    // get the current user
    const user = this._afAuth.auth.currentUser;

    // generate keywords
    const keywords = this._keywords.generateKeywords(utility.toLowerCase(user.displayName));

    // create new user data object
    const data: User = {
      uid: user.uid,
      keywords: keywords,
      displayName: user.displayName,
      email: user.email,
      emailVerified: false,
      phone: user.phoneNumber || null,
      address: {
        street: null,
        city: null,
        region: null
      },
      ads: 0,
      sold: 0,
      photoUrl: null,
      block: {
        incomplete: true,
        restrain: false
      },
      created: firebase.firestore.Timestamp.now().toMillis()
    };

    // write data to cloud firestore
    return this._afs.doc(`users/${user.uid}`).set(data);
  }

  // Send email verfificaiton when new user sign up
  public sendVerificationMail() {
    const actionCodeSettings = {
      url: 'https://www.dickernet.com/login', // ?email=' + this._afAuth.auth.currentUser.email
      handleCodeInApp: false,
    };
    return this._afAuth.auth.currentUser.sendEmailVerification(actionCodeSettings);
  }

  // update user data in firestore
  public updateUserDocument(data: Partial<User>) {
    return this._afs.doc(`users/${data.uid}`).update(data);
  }

  // update auth email in authentication
  updateAuthEmail(email: string) {
    if (this.isLoggedIn()) {
      return this._afAuth.auth.currentUser.updateEmail(email);
    }
  }

  // update auth profile name & photo url in authentication
  updateAuthProfile(data: {displayName?: string, photoUrl?: string}) {
    if (this.isLoggedIn()) {
      return this._afAuth.auth.currentUser.updateProfile({displayName: data.displayName, photoURL: data.photoUrl});
    }
  }

  // update auth phone number in authentication
  public updateAuthPhoneNumber(phone: any) {
    if (this.isLoggedIn()) {
      return this._afAuth.auth.currentUser.updatePhoneNumber(phone);
    }
  }

  // update auth password in authentication
  public updateAuthPassword(password: string) {
    if (this.isLoggedIn()) {
      return this._afAuth.auth.currentUser.updatePassword(password);
    }
  }

  // login route to dashboard or profile
  public async routeOnLogin() {
    const user = this._afAuth.auth.currentUser;
    const token = await user.getIdTokenResult();

    if (token.claims.admin) {
      this._router.navigate(['/users/dashboard']);
    } else {
      this._router.navigate([`/users/profile/${user.uid}`]);
    }
  }

  /**
   * send password reset email
   */
  sendPasswordResetEmail(email: string) {
    const url = 'https://www.dickernet.com/login/?next=true';
    return this._afAuth.auth.sendPasswordResetEmail(email, {url: url});
  }

  /**
   * verify password reset code
   */
  verifyPasswordResetCode(code: string) {
    return this._afAuth.auth.verifyPasswordResetCode(code);
  }

  /**
   * confirm password reset
   * @param code 
   * @param newPassword 
   */
  confirmPasswordReset(code: string, newPassword: string) {
    return this._afAuth.auth.confirmPasswordReset(code, newPassword);
  } /* <--- End */

  /**
   * user delete account by self
   */
  public async deleteAccount() {
    const user = this._afAuth.auth.currentUser;
    return user.delete();
  }

  // logout
  public logout() {
    // access logged in user id
    const uid = this._afAuth.auth.currentUser.uid;

    // status reference
    const statusRef = this._afRDb.object(`status/${uid}`);
        
    // user is online
    statusRef.set({ isOnline: false });

    this._afAuth.auth.signOut();
    this._router.navigate(['']);
  }
}
