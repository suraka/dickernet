import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';

import { Ad } from './../models';

@Injectable({
  providedIn: 'root'
})
export class AdService {

  constructor(
    private _afs: AngularFirestore,
    private _storage: AngularFireStorage,
  ) {
  }

  // add product data to firestore
  public createAdDocument(data: Ad) {
    // write data to cloud firestore
    return this._afs.doc<Ad>(`ads/${data.aid}`).set(data);
  }

  // update ad data in firestore
  public updateAdDocument(data: Ad) {
    return this._afs.doc<Ad>(`ads/${data.aid}`).update(data);
  }

  // delete ad data in firestore & storage
  public deleteAd(uid: string, aid: string, filenames: []) {
    filenames.forEach((filename) => {
      const filePath = `users/${uid}/ads/${aid}/${filename}`;
      const fileRef = this._storage.ref(filePath);
      fileRef.delete();
    });

    return this._afs.doc<Ad>(`ads/${aid}`).delete();
  }
}
