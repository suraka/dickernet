import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root"
})
export class ImageCompressionService {
  public resizeImage(
    file: File,
    maxWidth: number,
    quality: number = 1
  ): Promise<File> {
    return new Promise((resolve, reject) => {
      const image = new Image();
      const fileName = file.name;
      const mime = file.type;
      image.src = URL.createObjectURL(file);
      image.onload = () => {
        const width = image.width;
        const height = image.height;

        // to maintain the aspect ratio of the output image
        const scaleFactor = maxWidth / width;

        const canvas = document.createElement("canvas");
        canvas.width = maxWidth;
        canvas.height = height * scaleFactor;

        const context = <CanvasRenderingContext2D>canvas.getContext("2d");
        context.drawImage(image, 0, 0, maxWidth, height * scaleFactor);
        canvas.toBlob(blob => {
          const img = new File([blob], fileName, {
            type: mime,
            lastModified: Date.now()
          });
          // compressed image
          resolve(img);
        }, mime, quality);
        // context.canvas.toDataURL(file.type, 'image/png', 0.5);
        // canvas.toBlob(resolve, file.type);
      };
      image.onerror = reject;
    });
  }
}
