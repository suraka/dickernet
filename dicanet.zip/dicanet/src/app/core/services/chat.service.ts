import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';

import { Chat } from './../models';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  private chatCollection: AngularFirestoreCollection<Chat>;

  constructor(
    private _afs: AngularFirestore,
  ) { 
    this.chatCollection = _afs.collection<Chat>('chats');
  }


  // Update the timestamp field with the value from the server
  /* updateTimestamp = docRef.update({
    timestamp: firebase.firestore.FieldValue.serverTimestamp()
  }); */
}
