import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class KeywordsService {

  constructor() { }

  /**
   * Use when Creating or Updating records in Database
   */
  public generateKeywords(value: string) {
    const arrayValue = this.convertStringToArray(value);
    const keywordsArray = this.loopier(arrayValue);
    const keywords = this.createKeywords(`${value}`);
    const all = new Set<string>(['', ...keywordsArray, ...keywords]);

    return [...all];
  }

  private convertStringToArray(str: string): string[] {
    return str.split(' ');
  }

  private loopier<array>(arrayValue: string[]): string[] {
    const strArray = [];
    // if it's 1 or 0 items, just return
    if (arrayValue.length <= 1) { return arrayValue; }

    // For each index in array
    for (let i = 0; i < arrayValue.length; i++) {
      // choose a random not-yet-placed item to place there
      // must be an item AFTER the current item, because the stuff
      // before has all already been placed
      // const randomChoiceIndex = this.randomIntFromInterval(i, arrayValue.length - 1);

      const keywords = this.createKeywords(arrayValue[i]);

      // place our random choice in the spot by swapping
      strArray.push(...keywords);
    }

    return strArray;
  }

  private createKeywords(words: string) {
    const arrayWords = [];
    let currentWord = '';

    words.split('').forEach((letter) => {
      currentWord += letter;
      arrayWords.push(currentWord);
    });

    return arrayWords;
  }

  /*
   * The recommended (simple) algorithm is the Fisher–Yates shuffle.
   * Its time complexity is O(n). It can even be done inplace.
   * You go from 0 - (n-1) and at each index i pick a random number between 0 - n-i and
   * move the element at the result into the i + thisRandomNumberth location in the array.
   *
   */
  shuffleInPlace<T>(array: T[]): T[] {
    // if it's 1 or 0 items, just return
    if (array.length <= 1) { return array; }

    // For each index in array
    for (let i = 0; i < array.length; i++) {
      // choose a random not-yet-placed item to place there
      // must be an item AFTER the current item, because the stuff
      // before has all already been placed
      const randomChoiceIndex = this.randomIntFromInterval(i, array.length - 1);

      // place our random choice in the spot by swapping
      [array[i], array[randomChoiceIndex]] = [array[randomChoiceIndex], array[i]];
    }
    return array;
  }

  randomIntFromInterval(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  reverse(str: string) {
    return str.split(' ').reverse().join(' ');
  }

  /**
   * Time complexity: O(N^2)
   * Assuming western Left to Right reading card players of course
   * This is how humans naturally sort cards.
   * Think about it, you go from left to right and step by step
   * put each card in its right place (aka do an insert).
   */
  insertionSort<T>(
    array: T[],
    cmp: (a: T, b: T) => number = (a: any, b: any) => a - b
  ): T[] {
    let current: T;
    let j: number;
    for (let i = 1; i < array.length; i += 1) {
      current = array[i];
      j = i - 1;
      while (j >= 0 && cmp(array[j], current) > 0) {
          array[j + 1] = array[j];
          j -= 1;
      }
      array[j + 1] = current;
    }
    return array;
  }
}
