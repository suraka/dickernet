import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';

import { Message } from './../models';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  private messageCollection: AngularFirestoreCollection<Message>;

  constructor(
    private _afs: AngularFirestore,
  ) { 
    this.messageCollection = _afs.collection<Message>('messages');
  }

  // add message to firestore
  public createMessageDocument(data: Message) {
    // write data to cloud firestore
    return this.messageCollection.doc(`${data.mid}`).set(data);
  }

  // get messages
  public getMessages() {
    const messageRef = this.messageCollection.ref.limit(30);
    return messageRef.get();
  }

  // update message in firestore
  public updateMessageDocument(data: Message) {
    // updtae data in cloud firestore
    return this.messageCollection.doc(data.mid).update(data);
  }

  // delete message document
  public deleteMessage(mid: string) {
    return this.messageCollection.doc(mid).delete();
  }
}
