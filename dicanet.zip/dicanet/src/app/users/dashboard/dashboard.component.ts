import { Component, OnInit, Inject, NgZone, ViewChild, OnDestroy } from '@angular/core';
import { Observable, Subscription, of } from 'rxjs';
import { FormControl } from '@angular/forms'
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';

import { User, Ad, Message } from '../../core/models';
import { AuthService, AdService, MessageService, KeywordsService } from '../../core/services';

import { detailExpand } from './../../shared/animations';
import { ActivatedRoute, Router } from '@angular/router';
import * as utility from './../../core/utility';

export interface UsersTable {
  position: number;
  name: string;
  phone: string;
  address: string;
}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [detailExpand()]
})
export class DashboardComponent implements OnInit, OnDestroy {

  private currentUserDoc: AngularFirestoreDocument<User>;
  public currentUser$: Observable<User>;
  private _usersCollection: AngularFirestoreCollection<User>;
  private _adsCollection: AngularFirestoreCollection<Ad>;
  public users$: Observable<User[]>;
  public ads$: Observable<Ad[]>;
  public feedbacks$: Observable<Message[]>;
  public contacts$: Observable<Message[]>;
  public downloadUrl$: Observable<string>;
  public isNotUsers: boolean = true;
  public color: string = 'primary';
  public usersSubscription: Subscription;
  private _userDialogSubscription: Subscription;
  public isLoadingPublish: boolean = false;
  public isLoadingFeedback: boolean = false;
  public isLoadingContact: boolean = false;
  public isLoadingDelete: boolean = false;
  public error: string;
  public colorRipple: string = '#5f42e0';

  //dataSource = ELEMENT_DATA;
  //displayedColumns: string[] = ['position', 'name', 'phone', 'address'];
  //dataSource$: Observable<UsersTable[]>;
  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource: PeriodicElement[]; // = ELEMENT_DATA;
  
  usersColumnsToDisplay: string[] = ['uid', 'displayName', 'block'];
  adsColumnsToDisplay = ['title', 'price', 'status'];
  userExpandedElement: User | null;
  adExpandedElement: Ad | null;

  constructor(
    private _ngZone: NgZone,
    public afAuth: AngularFireAuth,
    private _afs: AngularFirestore,
    private _afStorage: AngularFireStorage,
    public auth: AuthService,
    public dialog: MatDialog,
    private _ad: AdService,
    private _snackBar: MatSnackBar,
    private _message: MessageService,
    private _keywords: KeywordsService,
  ) {
    const uid = this.afAuth.auth.currentUser.uid;
    this.currentUserDoc = this._afs.doc<User>(`users/${uid}`);
    this.currentUser$ = this.currentUserDoc.valueChanges();

    this._usersCollection = _afs.collection<User>('users');
    this.users$ = this._usersCollection.valueChanges();

    this._adsCollection = _afs.collection<Ad>('ads');
    this.ads$ = this._adsCollection.valueChanges();

    const feedbacks = this._afs.collection<Message>('messages', ref => ref.where('type', '==', 'feedback'));
    this.feedbacks$ = feedbacks.valueChanges();

    const contacts = this._afs.collection<Message>('messages', ref => ref.where('type', '==', 'contact'));
    this.contacts$ = contacts.valueChanges();

    // READ CAREFULLY BEFORE YOU UNCOMMENT THIS SNIPPET OF CODE
    // this two snippets of code loop through all ads &&
    // users in firestore and update each accordingly
    /* 
    (1)
    this.ads$.subscribe((ads) => {
      ads.forEach((ad) => {
        const title = utility.toLowerCase(ad.title);
        const desc = utility.toLowerCase(ad.description)
        const keywords = this._keywords.generateKeywords(title);

        const data: Ad = {
          aid: ad.aid,
          title: title,
          description: desc,
          keywords: keywords
        }

        try {
          this.ad.updateAdDocument(data)
            .then((resp) => console.log('Success: ', resp))
            .catch((res) => console.log('Failed: ', res));
        } catch(error) { 
          console.log(error.message) ;
        }
      })
    });

    (2)
    this.users$.subscribe((users) => {
      users.forEach((user) => {
        const displayName = utility.toLowerCase(user.displayName);
        const keywords = this._keywords.generateKeywords(displayName);

        const data: User = {
          uid: user.uid,
          displayName: displayName,
          keywords: keywords
        }

        try {
          this.auth.updateUserDocument(data)
            .then((resp) => console.log('Success: ', resp))
            .catch((res) => console.log('Failed: ', res));
        } catch(error) { 
          console.log(error.message) ;
        }
      })
    });
     */
   
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    if (this._userDialogSubscription) {
      this._userDialogSubscription.unsubscribe();
    }
  }

  public openUserDialog(user: Partial<User>): void {
    const dialogRef = this.dialog.open(UserDialogOverview, {
      width: '512px',
      data: user
    });

    this._userDialogSubscription = dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.animal = result;
    });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async publishOrBlockAd(aid: string, publish: boolean) {
    this.isLoadingPublish = true;
    this.error = null;

    const data: Ad = {
      aid,
      public: publish ? false : true,
    };

    if (confirm(publish ? 'Are you sure you want to block this ad?' : 'Are you sure you want to publish this ad?') === true) {
      try {
        await this._ad.updateAdDocument(data);

        const title = publish ? 'Block - Successful' : 'Publish - Successful';
        const msg = publish ? 'Ad is now block.' : 'Ad has now gone public.';

        this.openSnackBar(msg, title);
      } catch(error) {
        console.log(error.message);
        this.error = error.message;
      }
    }

    this.isLoadingPublish = false;
  }

  async deleteAd(uid: string, aid: string, filenames: []) {
    this.isLoadingDelete = true;

    if (confirm('Are you sure you want to delete this ad?') === true) {
      try {
        await this._ad.deleteAd(uid, aid, filenames);

        const title = 'Delete - Successful';
        const msg = 'Ad is now deleted from the platform.';

        this.openSnackBar(msg, title);
      } catch(error) {
        console.log(error.message);
        this.error = error.message;
      }
    }

    this.isLoadingDelete = false;
  }

  public async deleteMessage(mid: string, type: string) {
    this.isLoadingFeedback = true;
    this.error = null;
    let title: string; 
    let msg: string = 'Deleted';

    try {
      await this._message.deleteMessage(mid);
      if (type === 'feedback') {
        msg = 'Feedback was deleted.';
      } else {
        msg = 'Contact message was deleted.';
      }

      this.openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoadingFeedback = false;
  }
}

/* @Component({
  selector: 'feedback-dialog-overview',
  templateUrl: 'feedback-dialog-overview.html',
})
export class FeedbackDialogOverview implements OnInit{

  public feedbacks$: Observable<Message[]>;
  public isLoading: boolean = false;
  public error: string;
  
  constructor(
    public dialogRef: MatDialogRef<FeedbackDialogOverview>,
    @Inject(MAT_DIALOG_DATA) public data: Message,
    private _afs: AngularFirestore,
    private _message: MessageService,
    private _snackBar: MatSnackBar,
  ) {
    const feedbacks = this._afs.collection<Message>('messages', ref => ref.where('type', '==', 'feedback'));
    this.feedbacks$ = feedbacks.valueChanges();
  }

  ngOnInit() {
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  public async delete(mid: string) {
    this.isLoading = true;
    this.error = null;

    try {
      await this._message.deleteMessage(mid);

      const title = 'Deleted';
      const msg = 'Feedback was deleted.';

      this.openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
    
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

} */

/*
 * User Dialog Box
 */
@Component({
  selector: 'user-dialog-overview',
  templateUrl: 'user-dialog-overview.html',
})
export class UserDialogOverview implements OnInit {

  // public isAdmin: boolean = false;
  public advertiser$: Observable<User>; 
  public isLoadingUserAccessControl: boolean = false;
  public isLoadingDelete: boolean = false;
  public error: string;

  constructor(
    public dialogRef: MatDialogRef<UserDialogOverview>,
    @Inject(MAT_DIALOG_DATA) public data: Partial<User>, // contains user uid only
    public _afAuth: AngularFireAuth,
    private _afs: AngularFirestore,
    private _snackBar: MatSnackBar,
    private _auth: AuthService,
    public router: Router
  ) {
    // access advertiser document in firestore
    const advertiserDoc: AngularFirestoreDocument<User> = _afs.doc<User>(`users/${data.uid}`);
    this.advertiser$ = advertiserDoc.valueChanges();

    console.log(data.uid);
  }

  ngOnInit() { 
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  public async toggleUserAccessControl(user: User) {
    this.isLoadingUserAccessControl = true;
    this.error = null;

    try {
      const data: Partial<User> = {
        uid: user.uid,
        block: {
          restrain: user.block.restrain ? false : true
        }
      }

      await this._auth.updateUserDocument(data);

      const title = 'Control';
      const msg = 'User account updated successfully.';

      this.openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoadingUserAccessControl = false;
  }

  public async deleteCurrentUserAccount() {
    this.isLoadingDelete = true;
    this.error = null;

    try {
      // await this._auth.deleteAccount();
      //await this._auth.updateUserDocument();

      const title = 'Delete';
      const msg = 'User account deleted successfully.';

      this.openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoadingDelete = false;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}