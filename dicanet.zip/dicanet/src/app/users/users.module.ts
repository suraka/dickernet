import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { LazyLoadImageModule } from 'ng-lazyload-image';

import { UsersRoutingModule } from './users-routing.module';
import { MaterialModules } from './../material';
import { SharedModule } from './../shared';

import { 
  ProfileComponent, 
  EditProfileDialogComponent, 
  PreviewAdBottomSheetComponent 
} from './profile/profile.component';
import { DashboardComponent, UserDialogOverview } from './dashboard/dashboard.component';

export const COMPONENTS = [
  ProfileComponent, 
  DashboardComponent,
  UserDialogOverview,
  EditProfileDialogComponent,
  PreviewAdBottomSheetComponent
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    LazyLoadImageModule,
    UsersRoutingModule,
    MaterialModules,
    SharedModule,
  ],
  entryComponents: [
    UserDialogOverview,
    EditProfileDialogComponent,
    PreviewAdBottomSheetComponent
  ]
})
export class UsersModule { }
