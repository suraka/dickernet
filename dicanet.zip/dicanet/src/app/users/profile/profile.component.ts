import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { 
  MatBottomSheet, 
  MatBottomSheetRef, 
  MAT_BOTTOM_SHEET_DATA 
} from '@angular/material/bottom-sheet';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormControl, Validators } from '@angular/forms';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';

import { Observable, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { REGIONS } from './../../core/constants.data'; 
import { User, Ad } from './../../core/models';

import { routerTransition } from './../../shared/animations';
import { AuthService, KeywordsService, ImageCompressionService } from '../../core/services';
import * as utility from './../../core/utility';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  animations: [routerTransition()]
})
export class ProfileComponent implements OnInit, OnDestroy {

  private uid: string;
  private currentUserDoc: AngularFirestoreDocument<User>;
  public currentUser$: Observable<User>;
  public downloadUrl$: Observable<string>;
  public ads$: Observable<Ad[]>;
  public uploadProgress$: Observable<number>;
  public color: string = 'warn';
  public mode: string = 'buffer';
  public isLoading: boolean = false;
  public isSending: boolean = false;
  public error: string;
  private _currentUserSubscription: Subscription;
  private _downloadSubscription: Subscription;
  private _downloadCompressedSubscription: Subscription;
  private _editProfileDialogSubscription: Subscription;
  private _taskSubscription: Subscription;

  constructor(
    private route: ActivatedRoute,
    public afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private afStorage: AngularFireStorage,
    public auth: AuthService,
    private _dialog: MatDialog,
    private _bottomSheet: MatBottomSheet,
    private _snackBar: MatSnackBar,
    private _imageCompressor: ImageCompressionService
  ) {
    // access uid from the route
    this.uid = this.route.snapshot.paramMap.get('id');

    /* this.downloadUrl$ = this.afStorage
      .ref(`users/${this.uid}/profile-image`)
      .getDownloadURL(); */

    // access ad document in firestore
    this.ads$ = afs.collection('ads', 
                ref => ref.where('uid', '==', this.uid).orderBy('created')).valueChanges();
  }

  ngOnInit() {
    this.currentUserDoc = this.afs.doc<User>(`users/${this.uid}`);
    this.currentUser$ = this.currentUserDoc.valueChanges();

    this._currentUserSubscription = this.currentUser$.subscribe((currentUser) => {
      if (!currentUser.emailVerified && this.afAuth.auth.currentUser.emailVerified) {
        const data: User = {
          uid: currentUser.uid,
          emailVerified: true
        }
        const title = 'Verification';
        const msg = `Your email: ${currentUser.email} was successfully verified.`;

        this.auth.updateUserDocument(data).finally(() => {
          this.openSnackBar(title, msg);
        });
      }
    })

  }

  ngOnDestroy() {
    if (this._currentUserSubscription) {
      this._currentUserSubscription.unsubscribe();
    }

    if (this._downloadSubscription) {
      this._downloadSubscription.unsubscribe();
    }

    if (this._downloadCompressedSubscription) {
      this._downloadCompressedSubscription.unsubscribe();
    }

    if (this._editProfileDialogSubscription) {
      this._editProfileDialogSubscription.unsubscribe();
    }

    if (this._taskSubscription) {
      this._taskSubscription.unsubscribe();
    }
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async sendVerificationMail() {
    this.isSending = true;
    
    try {
      await this.auth.sendVerificationMail();
    } catch(error) {
      console.log(error.message);
    }

    this.isSending = false;
  }

  toggleVerifiedEmail(): void {
    this._bottomSheet.open(PreviewAdBottomSheetComponent, {
      data: { 
        email: ['info.dickernet@gmail.com'], 
        info: 'We appreciate your time and our team will follow up on your feedback.'
      },
    });
  }

  public openEditProfileDialog(user: User) {
    const dialogRef = this._dialog.open(EditProfileDialogComponent, {
      width: '512px',
      data: user
    });

    this._editProfileDialogSubscription = dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.response = result;
    });
  }

  public async fileChange(event) {
    // start uploading
    this.isLoading = true;

    // clear properties
    this.downloadUrl$ = null;
    this.error = null;

    // get uploaded file
    const file = await this._imageCompressor.resizeImage(event.target.files[0], 240, 1);
    const compressedImage = await this._imageCompressor.resizeImage(file, 45, 0);
    console.log(`original size: ${event.target.files[0].size}, compress size 1: ${file.size} bytes, compress size 2: ${compressedImage.size} bytes`);

    // create original && compressed file reference
    const filePath = `users/${this.uid}/profile-image`;
    const compressedFilePath = `users/${this.uid}/compressed-image`;
    const fileRef = this.afStorage.ref(filePath);
    const compressedFileRef = this.afStorage.ref(compressedFilePath);

    // upload and store both original && compressed
    const task = this.afStorage.upload(filePath, file);
    this.afStorage.upload(compressedFilePath, compressedImage);
    
    // check for errors in uploading
    task.catch(error => {
      console.log(`task original: ${error.message}`);
      this.error = error.message;
    });

    // monitor uploading progress
    this.uploadProgress$ = task.percentageChanges();

    // get notified when the download url is available
    this._taskSubscription = task.snapshotChanges().pipe(finalize(() => {
      this.downloadUrl$ = fileRef.getDownloadURL();
      const downloadCompressedUrl = compressedFileRef.getDownloadURL();
      this._downloadSubscription = this.downloadUrl$.subscribe(async (photoUrl) => {
        this._downloadCompressedSubscription = downloadCompressedUrl.subscribe(async (compressedPhotoUrl) => {
          await this.auth.updateUserDocument({
            uid: this.uid, 
            photoUrl: photoUrl, 
            compressedPhotoUrl: compressedPhotoUrl
          });
        });
        await this.auth.updateAuthProfile({ photoUrl: photoUrl });
      });
      
      this.isLoading = false;
    })).subscribe();
  }
}

/**
 * Verified Email Address Bottom Sheet
 */
@Component({
  selector: 'preview-ad',
  templateUrl: 'preview.ad.component.html',
})
export class PreviewAdBottomSheetComponent implements OnInit {
 
  public email = new FormControl('', [Validators.required, Validators.email]);
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private _bottomSheetRef: MatBottomSheetRef<PreviewAdBottomSheetComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _afs: AngularFirestore,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit() {
  }

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' : '';
  }

  closeBottomSheetVerifiedEmail(event: MouseEvent): void {
    this._bottomSheetRef.dismiss();
    event.preventDefault();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onSubmitEmail(event: MouseEvent) {
    this.isLoading = true;
    this.error = null;

    // create document reference, id
    //const mid = this._afs.createId();

    // access feedback form data
    const { email } = this.email.value;

    /* const data: Message = {
      mid,
      fullname,
      address,
      satisfied,
      message,
      type: 'feedback',
      seen: false,
      created: firebase.firestore.Timestamp.now().toMillis()
    } */

    const title = 'Feedback';
    const msg = `Your feedback was sent to ${this.data.email} successfully.`;

    try {
      //await this.message.createMessageDocument(data);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
    this.closeBottomSheetVerifiedEmail(event);
    this.openSnackBar(msg, title);
  }
}

/* Edit Profile Dialog Component */
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit.profile.dialog.component.html',
})
export class EditProfileDialogComponent implements OnInit, OnDestroy {

  public uploadProgress$: Observable<number>
  public regions = REGIONS;
  public color: string = 'primary';
  public swap: boolean = false;
  public isLoading: boolean = false;
  public isAdmin: boolean = false;
  public error: string;
  public fullname: string;
  public email: string;
  public phone: string;
  public street: string;
  public city: string;
  public region: string;
  public acceptance: string = null;
  private _adminSubscription: Subscription;
  
  constructor(
    public dialogRef: MatDialogRef<EditProfileDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public user: User,
    public afAuth: AngularFireAuth,
    private _keywords: KeywordsService,
    private _auth: AuthService,
    private _snackBar: MatSnackBar,
  ) {
    // access admin status
    this._adminSubscription = afAuth.idTokenResult.subscribe((token: any) => {
      if (this._auth.isLoggedIn()) {
        if (token.claims.admin) {
          this.isAdmin = token.claims.admin;
        } else {
          this.isAdmin = false;
        }
      }
    }, (error) => console.log(error));
  }

  ngOnInit() {}

  ngOnDestroy() {
    if (this._adminSubscription) {
      this._adminSubscription.unsubscribe();
    }
  }

  private _openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  public async onSubmitEditedProfile(ngForm: NgForm) {
    this.isLoading = true;
    this.error = null;

    // get profile data
    const { fullname, email, phone, street, city, region, acceptance } = ngForm.form.getRawValue();

    if (!fullname || !email || !phone || !street || !city || !region) {
      this.isLoading = false;
      return this.error = 'You must fully enter all information before submitting!';
    } 

    // check acceptance
    if (!acceptance) {
      this.isLoading = false;
      return this.error = 'You must agree to our terms & conditions!';
    }

    // generate keywords
    const keywords = this._keywords.generateKeywords(utility.toLowerCase(fullname));

    // create user object
    const user: User = {
      uid: this.user.uid,
      keywords: keywords,
      displayName: fullname,
      email,
      phone,
      address: {
        street: street,
        city: city,
        region: region
      },
      block: {
        incomplete: false
      }
    };

    try {
      await this._auth.updateUserDocument(user);
      this.user.phone !== phone ? await this._auth.updateAuthPhoneNumber(phone) : '';
      this.user.displayName !== fullname ? await this._auth.updateAuthProfile({displayName: fullname}) : '';

      const title = 'Updated';
      const msg = 'Profile updated successful.';

      this.dialogRef.close();
      this._openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}