import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { 
  AngularFireAuthGuard,
  //hasCustomClaim, 
  customClaims,
  //redirectUnauthorizedTo, 
 } from '@angular/fire/auth-guard';
 import { pipe } from 'rxjs';
 import { map } from 'rxjs/operators';

import { ProfileComponent } from './profile/profile.component';
import { DashboardComponent } from './dashboard/dashboard.component';

/* const redirectLoggedInToProfile = () => map(user => user ? ['profile', (user as any).uid] : true);
const onlyAllowSelf = next => map(user => (!!user && next.params.id == (user as any).uid) || ['/login']);
const redirectLoggedInToProfileOrDashboard  = () => pipe(
  customClaims, 
  map(claims => {
    // if no claims, then there is no authenticated user
    // so allow the route ['']
    if (claims.length === 0) {
      return true;
    }

    // if custom claim set redirect to ['dashboard']
    if (claims.admin) {
      return ['dashboard'];
    }

    // otherwise, redirect user's to profile page ['profile/:id]
    return ['profile', claims.user_id];
  })
); */
const adminOnly = () => pipe(customClaims, map(claims => claims.admin === true || ['/auth/login']));
const onlyAllowSelfOrAdmin = (next) => pipe(
  customClaims,
  map(claims => {
    if (claims.length === 0) {
      return [''];
    }

    return next.params.id === claims.user_id || claims.admin;
  })
);

const routes: Routes = [
  {
    path: 'profile/:id',
    component: ProfileComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: onlyAllowSelfOrAdmin }
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: adminOnly }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
