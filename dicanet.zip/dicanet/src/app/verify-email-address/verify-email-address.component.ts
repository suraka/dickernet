import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';

import { AuthService } from './../core/services';
import { User } from './../core/models';

import { routerTransition } from './../shared/animations';

@Component({
  selector: 'app-verify-email-address',
  templateUrl: './verify-email-address.component.html',
  styleUrls: ['./verify-email-address.component.scss'],
  animations: [routerTransition()],
})
export class VerifyEmailAddressComponent implements OnInit {

  public currentUser: User;

  constructor(
    private _auth: AuthService,
    public afAuth: AngularFireAuth,
  ) {
    if (this._auth.isLoggedIn()) {
      this.currentUser = this.afAuth.auth.currentUser;
    }
  }

  ngOnInit() {
    window.scrollTo(0, 0); // Scroll up
  }

}
