import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
//import { StoreModule } from '@ngrx/store';
//import { EffectsModule } from '@ngrx/effects';
import { AuthRoutingModule } from './auth-routing.module';
import { MaterialModules } from './../material';
import { SharedModule } from './../shared';

//import { AuthEffects } from './effects/auth.effects';
//import { reducers } from './reducers';

import { 
  LoginComponent, 
  ForgotPasswordEmailBottomSheetComponent,
  ForgotPasswordCodeBottomSheetComponent,
  ForgotPasswordNewBottomSheetComponent
 } from './login/login.component';

 export const COMPONENTS = [
  LoginComponent, 
  ForgotPasswordEmailBottomSheetComponent,
  ForgotPasswordCodeBottomSheetComponent,
  ForgotPasswordNewBottomSheetComponent
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AuthRoutingModule,
    MaterialModules,
    SharedModule,
    //StoreModule.forFeature('auth', reducers),
    //EffectsModule.forFeature([AuthEffects]),
  ],
  entryComponents: [
    ForgotPasswordEmailBottomSheetComponent,
    ForgotPasswordCodeBottomSheetComponent,
    ForgotPasswordNewBottomSheetComponent,
  ]
})
export class AuthModule { }
