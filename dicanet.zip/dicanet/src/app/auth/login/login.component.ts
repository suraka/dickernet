import { Component, OnInit, NgZone, OnDestroy, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { 
  MatBottomSheet, 
  MatBottomSheetRef, 
  MAT_BOTTOM_SHEET_DATA 
} from '@angular/material/bottom-sheet';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireDatabase } from '@angular/fire/database';
import { auth } from 'firebase/app';

import { AuthService } from './../../core/services';

import { routerTransition, fallIn } from './../../shared/animations';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [routerTransition(), fallIn()],
})
export class LoginComponent implements OnInit {

  public authForm: FormGroup;
  public isLoading: boolean = false;
  public isLoadingFacebook: boolean = false;
  public isLoadingGoogle: boolean = false;
  public action: 'login' | 'signup' = 'login'; // action property default to login
  public error: string;
  public color: string = 'primary';
  public mode: string = 'indeterminate';
  public value: number = 50;

  constructor(
    private _route: ActivatedRoute,
    private _snackBar: MatSnackBar,
    private _bottomSheet: MatBottomSheet,
    private _afAuth: AngularFireAuth,
    private _afRDb: AngularFireDatabase,
    public auth: AuthService,
    private _ngZone: NgZone // NgZone service to remove outside scope warning
  ) { }

  ngOnInit() {
    const nextToForgotPasswordCode = this._route.snapshot.paramMap.get('next');
    if (nextToForgotPasswordCode) {
      this._bottomSheet.open(ForgotPasswordCodeBottomSheetComponent);
    }
    
    // access user id and aid
    this.authForm = new FormGroup({
      firstname: new FormControl(''),
      lastname: new FormControl(''),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)])
    });

    this.authForm.reset();
    this.authForm.setValue({firstname: '', lastname: '', email: '', password: ''});
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  toggleForgotPasswordEmail(): void {
    this._bottomSheet.open(ForgotPasswordEmailBottomSheetComponent);
  }

  facebook() {
    this.authLogin(new auth.FacebookAuthProvider(), false);
  }

  google() {  
    this.authLogin(new auth.GoogleAuthProvider(), true);
  }

  // Auth logic to run auth providers
  async authLogin(provider: auth.AuthProvider, isGoogle: boolean) {
    isGoogle ? this.isLoadingGoogle = true : this.isLoadingFacebook = true;
    this.error = null;

    try {
      await this._afAuth.auth.signInWithPopup(provider);
      await this.auth.createUserDocument();
      this._ngZone.run(() => {
        this.auth.routeOnLogin();
      });
    }
    catch (error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isLoading = false;
  } /* <--- End */

  async onSubmitAuthForm() {
    this.isLoading = true;
    this.error = null;

    // access form fields
    const { firstname, lastname, email, password } = this.authForm.value
    let response: any;

    try {
      if (this.isSignUp) {
        response = await this._afAuth.auth.createUserWithEmailAndPassword(email, password);
        await response.user.updateProfile({displayName: `${firstname} ${lastname}`});
        await this.auth.createUserDocument();

        // status reference
        const statusRef = this._afRDb.object(`status/${response.user.uid}`);

        // user is online
        statusRef.set({ isOnline: true });
        this.authForm.reset();
      } else {
        await this._afAuth.auth.signInWithEmailAndPassword(email, password);

        // access logged in user id
        const uid = this._afAuth.auth.currentUser.uid;
        
        // status reference
        const statusRef = this._afRDb.object(`status/${uid}`);
        
        // user is online
        statusRef.set({ isOnline: true });
      }

      this.auth.routeOnLogin();
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }
    
    this.isLoading = false;
  }

  get isLogin() {
    return this.action === 'login';
  }

  get isSignUp() {
    return this.action === 'signup';
  }
}

/**
 * Forgot Password Email Section
 */
@Component({
  selector: 'forgot-password-email',
  templateUrl: 'forgot.password.email.component.html',
})
export class ForgotPasswordEmailBottomSheetComponent implements OnInit {
  
  public emailFormGroup: FormGroup;
  public isLoading: boolean = false;
  public error: string;
  private _next: any = null;

  constructor(
    private _bottomSheet: MatBottomSheet,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _auth: AuthService,
  ) {}

  ngOnInit() {
    this.emailFormGroup = this._formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onSubmitEmail() {
    this.isLoading = true;
    this.error = null;

    // access form field
    const { email } = this.emailFormGroup.value
    
    if (!email) {
      return this.error = 'You must provide email address!';
    }

    const title = 'Success';
    const msg = `An email was sent to ${email}. Check your email and copy the code.`;

    try {
      await this._auth.sendPasswordResetEmail(email);
      this.openSnackBar(msg, title);
      this._bottomSheet.open(ForgotPasswordCodeBottomSheetComponent);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }
  
    this.isLoading = false;
    this.emailFormGroup.reset();
  }
}

/**
 * Forgot Password Code Section
 */
@Component({
  selector: 'forgot-password-code',
  templateUrl: 'forgot.password.code.component.html',
})
export class ForgotPasswordCodeBottomSheetComponent implements OnInit {
  
  public codeFormGroup: FormGroup;
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private _bottomSheet: MatBottomSheet,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _auth: AuthService,
  ) {}

  ngOnInit() {
    this.codeFormGroup = this._formBuilder.group({
      code: ['', Validators.required]
    });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onSubmitCode() {
    this.isLoading = true;
    this.error = null;

    // access form fields
    const { code } = this.codeFormGroup.value

    if (!code) {
      return this.error = 'You must provide the code sent to your email!';
    }

    const title = 'Success';
    const msg = `Your code is valid.`;

    try {
      const email = await this._auth.verifyPasswordResetCode(code);
      if (email) {
        this.openSnackBar(msg, title);
        this._bottomSheet.open(ForgotPasswordNewBottomSheetComponent, {data: {code: code}});
      }
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }
  
    this.isLoading = false;
    this.codeFormGroup.reset();
  }
}

/**
 * Forgot Password New Section
 */
@Component({
  selector: 'forgot-password-new',
  templateUrl: 'forgot.password.new.component.html',
})
export class ForgotPasswordNewBottomSheetComponent implements OnInit {
  
  public newPasswordFormGroup: FormGroup;
  public hidePassword: boolean = true;
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private _router: Router,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _auth: AuthService,
  ) {}

  ngOnInit() {
    this.newPasswordFormGroup = this._formBuilder.group({
      newPassword: ['', Validators.required],
      repeatNewPassword: ['', Validators.required]
    });
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onSubmitNewPassword() {
    this.isLoading = true;
    this.error = null;

    // access form fields
    const { newPassword, repeatNewPassword } = this.newPasswordFormGroup.value

    if (newPassword !== repeatNewPassword) {
      return this.error = 'Your password does not match!';
    }

    const title = 'Success';
    const msg = `Your password reset process was successfully. You may now login with your new password. Thank you.`;

    try {
      await this._auth.confirmPasswordReset(this.data.code, newPassword);
      this._router.navigate(['auth/login']);
      this.openSnackBar(msg, title);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }
  
    this.isLoading = false;
    this.newPasswordFormGroup.reset();
  }
}