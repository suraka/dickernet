import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { 
  AngularFireAuthGuard,
  customClaims
 } from '@angular/fire/auth-guard';
 import { pipe } from 'rxjs';
 import { map } from 'rxjs/operators';

import { LoginComponent } from './login/login.component';

const redirectLoggedInToProfileOrDashboard  = () => pipe(
  customClaims, 
  map(claims => {
    // if no claims, then there is no authenticated user
    // so allow the route ['']
    if (claims.length === 0) {
      return true;
    }

    // if custom claim set redirect to ['dashboard']
    if (claims.admin) {
      return ['users/dashboard'];
    }

    // otherwise, redirect user's to profile page ['profile/:id]
    return ['users/profile', claims.user_id];
  })
);

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [AngularFireAuthGuard],
    data: { authGuardPipe: redirectLoggedInToProfileOrDashboard }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
