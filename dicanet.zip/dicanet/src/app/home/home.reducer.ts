import { Action, createReducer, on } from '@ngrx/store';
import { Ad } from './../core/models';
import * as HomeComponentActions from './../actions/home.actions';

export interface State {
  ads: Ad[];
  search: Ad[];
}

export const initialState: State = {
    ads: null,
    search: null,
};

const homeReducer = createReducer(
    initialState,
    on(HomeComponentActions.ads, state => ({ ...state, ads: state.ads })),
    //on(HomeComponentActions.searchAds, state => ({ ...state, search: state.search })),
    //on(HomeComponentActions.searchAds, (state, { query }) => ({ ads: query }))
  );
  
  export function reducer(state: State | undefined, action: Action) {
    return homeReducer(state, action);
  }