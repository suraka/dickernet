import { ChangeDetectionStrategy, Component, OnInit, AfterViewInit, Output, ViewChild } from '@angular/core';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { distinctUntilChanged, switchMap } from 'rxjs/operators';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { AngularFirestore } from '@angular/fire/firestore';

import { select, Store } from '@ngrx/store';

// import { KeywordsService, AdService } from './../core/services';
import * as fromAds from './../ads/reducers';
import { CollectionPageActions } from './../ads/actions';

import { Ad } from '../core/models';

import { slideToTop } from './../shared/animations';
import * as utility from './../core/utility';
import { AdService } from '../core/services';

@Component({
  selector: 'app-home',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  animations: [ slideToTop() ]
})
export class HomeComponent implements OnInit, AfterViewInit {

  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  public ads$: Observable<Ad[]>;
  public allPost$: Observable<Ad[]>;
  public categoryFilter$: BehaviorSubject<string|null>;
  public locationFilter$: BehaviorSubject<string|null>;
  public searchQuery$: BehaviorSubject<string|null>;
  public first$: BehaviorSubject<number|null>;
  public last$: BehaviorSubject<number|null>;
  public color: string = 'primary';
  public mode: string = 'indeterminate';
  public value: number = 20;
  public isReload: boolean = false;
  public pageIndex: number = 0;
  public pageSize = 5;
  public pageSizeOptions: number[] = [3, 5, 10, 25, 50, 100];
  public lowValue: number = 0;
  public highValue: number = 50;  
  public searchQuery: string;
  public location: string;
  public category: string;
  
  constructor(
    private _afs: AngularFirestore,
    //private _store: Store<fromAds.State>,
    public adService: AdService,
    // private _keywords: KeywordsService,
  ) {

    this.category = 'All Categories';
    this.location = 'All Locations';

    // clear all previous filters
    this.categoryFilter$ = new BehaviorSubject(null);
    this.locationFilter$ = new BehaviorSubject(null);
    this.searchQuery$ = new BehaviorSubject(null);
    this.first$ = new BehaviorSubject(null);
    this.last$ = new BehaviorSubject(null);

    this.ads$ = combineLatest(
      this.categoryFilter$,
      this.locationFilter$,
      this.searchQuery$,
      this.first$,
      this.last$
    ).pipe(
      // ignore category, location, or search if same as previous
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap(([category, location, search, first, last]) => 
        this._afs.collection('ads', ref => {
          let query : firebase.firestore.CollectionReference | firebase.firestore.Query = ref;
          if (category) { query = query.where('category', '==', category) };
          if (location) { query = query.where('address.region', '==', location) };
          if (search) { query = query.where('keywords', 'array-contains', search) };
          query = query.where('public', '==', true).orderBy('created', 'desc');
          return query; // last ? query.startAfter(last['created']).limit(this.pageSize) : first ? query.endBefore(first['created']).limitToLast(this.pageSize) : query.limit(this.pageSize);
        }).valueChanges()
      )
    );

    //this.allPost$ = this._store.pipe(select(fromAds.getAdCollection));
  }

  ngOnInit() {
    //this._store.dispatch(CollectionPageActions.loadCollection());
  }

  ngAfterViewInit() {
    /* this.paginator.page.subscribe(
      (event: PageEvent) => console.log('paginator: ', event)
    ); */
  }

  filterByCategory(category: string|null) {
    category === null ? this.category = 'All Categories' : this.category = category;
    this.categoryFilter$.next(category); 
  }

  filterByLocation(location: string|null) {
    location === null ? this.location = 'All Locations' : this.location = location;
    this.locationFilter$.next(location); 
  }

  searchAds(query: string) {
    this.searchQuery = query;

    // get the current search term ads
    this.searchQuery$.next(utility.toLowerCase(query));
  }

  nextPage(last: number) {
    console.log(last);
    this.last$.next(last)
  }

  prevPage(first: number) {
    console.log(first);
    this.first$.next(first);
  }

  onPageChanged(event: PageEvent) {
    const i = event.pageIndex;
    const s = event.pageSize;
    const l = event.length;
    const p = event.previousPageIndex;
    //this.first$.next(first);
    //this.last$.next(last);

    console.log(`index: ${i}, size: ${s}, length: ${l}, previous: ${p}`);
    let firstCut = event.pageIndex * event.pageSize;
    let secondCut = firstCut + event.pageSize;
    console.log('on changee', firstCut, secondCut);
  }


  /* getPaginatorData($event: PageEvent): PageEvent {
    console.log(event);
    if(event.pageIndex === this.pageIndex + 1){
       this.lowValue = this.lowValue + this.pageSize;
       this.highValue =  this.highValue + this.pageSize;
      }
   else if(event.pageIndex === this.pageIndex - 1){
      this.lowValue = this.lowValue - this.pageSize;
      this.highValue =  this.highValue - this.pageSize;
     }   
      this.pageIndex = event.pageIndex;
      return event;
  } */

}
