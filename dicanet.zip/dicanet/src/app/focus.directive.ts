import { AfterContentChecked, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: 'input[my-input-focus]'
})
export class InputFocusDirective implements AfterContentChecked {

  constructor(private element: ElementRef<HTMLInputElement>) {}

  ngAfterContentChecked(): void {
    this.element.nativeElement.focus();
  }

}
