import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";
import { defer, Observable, of } from "rxjs";
import { catchError, map, mergeMap, switchMap, toArray } from "rxjs/operators";
import {
  CollectionPageActions,
  FirestoreCollectionActions,
  SelectedAdPageActions
} from "./ads/actions";

import { AngularFirestore } from "@angular/fire/firestore";

import { Ad } from "./core/models";

@Injectable()
export class AppEffects {
  constructor(
    private actions$: Actions,
    private readonly _afs: AngularFirestore
  ) {
    this.actions$.pipe(
      ofType(CollectionPageActions.loadCollection.type),
      switchMap(() =>
        this._afs
          .collection<Ad>("ads")
          .valueChanges()
          .pipe(
            //toArray(),
            map((ads: Ad[]) => FirestoreCollectionActions.loadAdsSuccess({ ads })),
            catchError(error =>
              of(FirestoreCollectionActions.loadAdsFailure({ error }))
            )
          )
      )
    );
  }
}
