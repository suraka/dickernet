import { Component, OnDestroy } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subscription } from 'rxjs';

import { ConnectionService } from 'ng-connection-service';

import { AuthService } from './core/services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {

  public hasNetworkConnection: boolean;
  public hasInternetAccess: boolean;
  public isConnected: boolean = true;
  private _connectionSubscription: Subscription;

  constructor(
    private _snackBar: MatSnackBar,
    private connectionService: ConnectionService,
    public auth: AuthService,
  ) {
    this._connectionSubscription = this.connectionService.monitor().subscribe(isConnected => {
      this.isConnected = isConnected;
      if (this.isConnected) {
        this.openSnackBar('You are now connected', 'ONLINE')
      }
      else {
        this.openSnackBar('You are now disconnected', 'OFFLINE')
      }
    });

    if (!('indexedDB' in window)) {
      console.log('This browser doesn\'t support IndexedDB');
      return;
    }
  }

  ngOnDestroy() {
    if (this._connectionSubscription) {
      this._connectionSubscription.unsubscribe();
    }
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }
}


