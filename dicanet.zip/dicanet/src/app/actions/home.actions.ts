import { createAction, props } from '@ngrx/store';

export const ads = createAction('[Home Component] Get Ads');

export const searchAds = createAction(
    '[Home Component] Search Ads', 
    props<{query: string}>()
);