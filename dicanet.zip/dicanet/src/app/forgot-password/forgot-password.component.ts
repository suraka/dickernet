import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

import { AuthService } from './../core/services';

import { routerTransition, fallIn } from './../shared/animations';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  animations: [routerTransition(), fallIn()],
})
export class ForgotPasswordComponent implements OnInit {

  public lossPasswordForm: FormGroup;
  public isLoading: boolean = false;
  public error: string;
  public isStepOneCompleted = true; // Enter email to start password reset process
  public isStepTwoCompleted = false; // Enter code sent to your provided email address
  public isStepThreeCompleted = false; // Enter a new password 
  private confirmEmail: string;
  private _next: any = null;

  constructor(
    private _route: ActivatedRoute,
    private auth: AuthService,
    private router: Router,
    private _snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    // access uid from the route
    this._next = this._route.snapshot.paramMap.get('next');

    if (this._next !== null) {
      this.isStepOneCompleted = !this.isStepOneCompleted;
      this.isStepTwoCompleted = !this.isStepTwoCompleted;
    }

    this.lossPasswordForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      code: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required]),
      repeatPassword: new FormControl('', [Validators.required])
    });
  }

  // Getter easy access to form fields
  get email() { return this.lossPasswordForm.get('email'); }
  get code() { return this.lossPasswordForm.get('code'); }
  get password() { return this.lossPasswordForm.get('password'); }
  get repeatPassword() { return this.lossPasswordForm.get('repeatPassword'); }

  toggleStepOne() {
    if (this.email.value === null) {
      this.error = 'Enter your email address!';
    }

    if (this.email.value !== null) {
      this.auth.sendPasswordResetEmail(this.email.value).then(() => {
        this.isStepOneCompleted = !this.isStepOneCompleted;
        this.isStepTwoCompleted = !this.isStepTwoCompleted;
      });
    }
  }

  toggleStepTwo() {
    if (this.code.value === null) {
      this.error = 'You must enter the code sent your email!';
    }

    if (this.code.value !== null) {
      this.auth.verifyPasswordResetCode(this.code.value).then((res) => {
        this.confirmEmail = res;
        this.isStepTwoCompleted = !this.isStepTwoCompleted;
        this.isStepThreeCompleted = !this.isStepThreeCompleted;
      });
    }
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }

  async onChangePassword() {
    this.isLoading = true;
    this.error = null;

    if (this.confirmEmail !== this.email.value) {
      return this.error = 'Your email does not match!';
    }

    if (this.password.value !== this.repeatPassword.value) {
      return this.error = 'Your password does not match!';
    }

    const title = 'Success';
    const msg = `Your password reset process was successfully. You may now login with your new password. Thank you.`;

    try {
      await this.auth.confirmPasswordReset(this.code.value, this.password.value);
    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }
  
    this.isLoading = false;
    this.lossPasswordForm.reset();
    this.router.navigate(['auth/login']);
    this.openSnackBar(msg, title);
  }

}
