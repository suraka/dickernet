import { EntityMetadataMap, EntityDataModuleConfig } from '@ngrx/data';
import { Ad } from './core/models';

const entityMetadata: EntityMetadataMap = {
  Ad: {
    entityName: 'Ad',
    entityDispatcherOptions: { optimisticAdd: true, optimisticUpdate: true }
  }
};

const pluralNames = { Ad: 'ads' };

export const entityConfig: EntityDataModuleConfig = {
  entityMetadata,
  pluralNames
};
