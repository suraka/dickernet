import {
    trigger, state, style, transition,
    animate, group, query, stagger, keyframes
} from '@angular/animations';

export function routerTransition() {
    return slideToLeft();
}

export function sidebarTransition() {
    return slideToRight();
}

export function fallInToggle() {
    return fallIn();
}

export function moveInToggle() {
    return moveIn();
}

export function showPhoneToggle() {
    return showPhone();
}

export function detailExpand() {
    return trigger('detailExpand', [
        state('collapsed', style({height: '0px', minHeight: '0'})),
        state('expanded', style({height: '*'})),
        transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]);
}

export function moveIn() {
    return trigger('moveInToggle', [
      state('void', style({position: 'fixed', width: '100%'}) ),
      state('*', style({position: 'fixed', width: '100%'}) ),
      transition(':enter', [
        style({opacity: '0', transform: 'translateX(100px)'}),
        animate('.6s ease-in-out', style({opacity: '1', transform: 'translateX(0)'}))
      ]),
      transition(':leave', [
        style({opacity: '1', transform: 'translateX(0)'}),
        animate('.3s ease-in-out', style({opacity: '0', transform: 'translateX(-200px)'}))
      ])
    ]);
}

export function fallIn() {
    return trigger('fallInToggle', [
      transition(':enter', [
        style({opacity: '0', transform: 'translateY(40px)'}),
        animate('.4s .2s ease-in-out', style({opacity: '1', transform: 'translateY(0)'}))
      ]),
      transition(':leave', [
        style({opacity: '1', transform: 'translateY(0)'}),
        animate('.3s ease-in-out', style({opacity: '0', transform: 'translateY(-200px)'}))
      ])
    ]);
}

export function moveInLeft() {
    return trigger('moveInLeft', [
      transition(':enter', [
        style({opacity: '0', transform: 'translateX(-100px)'}),
        animate('.6s .2s ease-in-out', style({opacity: '1', transform: 'translateX(0)'}))
      ])
    ]);
}

export const SlideInOutAnimation = [
    trigger('slideInOut', [
        state('in', style({
            'max-height': '500px',
            opacity: '1',
            visibility: 'visible'
        })),
        state('out', style({
            'max-height': '0px', opacity: '0', visibility: 'hidden'
        })),
        transition('in => out', [group([
            animate('400ms ease-in-out', style({
                opacity: '0'
            })),
            animate('600ms ease-in-out', style({
                'max-height': '0px'
            })),
            animate('700ms ease-in-out', style({
                visibility: 'hidden'
            }))
        ]
        )]),
        transition('out => in', [group([
            animate('1ms ease-in-out', style({
                visibility: 'visible'
            })),
            animate('600ms ease-in-out', style({
                'max-height': '500px'
            })),
            animate('800ms ease-in-out', style({
                opacity: '1'
            }))
        ]
        )])
    ]),
];

/* ROUTER ANIMATIONS
-------------------------------------------------------------------------------------------*/
/* Import into component ts & add 'animations: [slideToRight()]' to '@Component' decorator */
/* Add '[@slideToRight]' to your div element in component html you wish to animate */
export function slideToRight() {
    return trigger('sidebarTransition', [
        state('void', style({})),
        state('*', style({})),
        transition(':enter', [
            style({ transform: 'translateX(-100%)' }),
            animate('0.5s ease-in-out', style({ transform: 'translateX(0%)' }))
        ]),
        transition(':leave', [
            style({ transform: 'translateX(0%)' }),
            animate('0.5s ease-in-out', style({ transform: 'translateX(100%)' }))
        ])
    ]);
}

export function slideToLeft() {
    return trigger('routerTransition', [
        state('void', style({})),
        state('*', style({})),
        transition(':enter', [
            style({ opacity: '0', transform: 'translateX(100%)' }),
            animate('0.6s ease-in-out', style({ opacity: '1', transform: 'translateX(0%)' }))
        ]),
        transition(':leave', [
            style({ opacity: '1', transform: 'translateX(0%)' }),
            animate('0.3s ease-in-out', style({ opacity: '0', transform: 'translateX(-100%)' }))
        ])
    ]);
}

export function slideToBottom() {
    return trigger('slideToBottom', [
        state('void', style({})),
        state('*', style({})),
        transition(':enter', [
            style({ transform: 'translateY(-100%)' }),
            animate('0.5s ease-in-out', style({ transform: 'translateY(0%)' }))
        ]),
        transition(':leave', [
            style({ transform: 'translateY(0%)' }),
            animate('0.5s ease-in-out', style({ transform: 'translateY(100%)' }))
        ])
    ]);
}

export function slideToTop() {
    return trigger('slideToTop', [
        state('void', style({})),
        state('*', style({})),
        transition(':enter', [
            style({ opacity: '0', transform: 'translateY(100%)' }),
            animate('1.2s ease-in-out', style({ opacity: '1', transform: 'translateY(0%)' }))
        ]),
        transition(':leave', [
            style({ opacity: '1', transform: 'translateY(0%)' }),
            animate('0.3s ease-in-out', style({ opacity: '0', transform: 'translateY(-100%)' }))
        ])
    ]);
}

export function showPhone() {
    return trigger('showPhoneToggle', [
        state('void', style({})),
        state('*', style({})),
        transition(':enter', [
            style({ opacity: '0', transform: 'translateX(100%)' }),
            animate('0.3s ease-in-out', style({ opacity: '0.7', transform: 'translateX(0%)' }))
        ]),
        transition(':leave', [
            style({ opacity: '1', transform: 'translateX(0%)' }),
            animate('0.3s ease-in-out', style({ opacity: '0', transform: 'translateX(100%)' }))
        ])
    ]);
}