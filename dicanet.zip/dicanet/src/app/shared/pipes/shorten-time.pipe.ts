import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shortenTime'
})
export class ShortenTimePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return null;
  }

}
