import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';

interface Message {
  from: string,
  loggedInUserUID: string
}

/*
 * Styles a message based on its origin.
 */
@Pipe({
  name: 'stylize'
})
export class StylizePipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer) {}

  transform(message: Message): string|SafeStyle {
    if (!message) {
      return '';
    }

    let style = '';

    // Change font style of each message based on who's posting
    if (message.from == message.loggedInUserUID) {
      style += `
                font-family: 'Bonbon', 'Roboto', 'Helvetica', sans-serif; 
                float: right;
                color: #fff;
                text-align: left;
                background: linear-gradient(120deg, #248a52, #257287);
                border-radius: 10px 10px 0 10px;
              `;
    } else if (message.from != message.loggedInUserUID) {
      style += `
                font-family: 'Crafty Girls', 'Roboto', 'Helvetica', sans-serif; 
                clear: both;
                float: left;
                max-width: 220px;
                padding: 6px 10px 7px;
                border-radius: 10px 10px 10px 0;
                background: rgba(0, 0, 0, 0.623);
                //margin: 8px 0;
                margin-top: 8px;
                font-size: 14px;
                line-height: 1.4;
                margin-left: 10px;
                margin-right: 10px;
                position: relative;
                text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
              `;
    } 
    // Change font based on positive/negative score.
    /* if (sentiment.score >= 0.9) {
      style += `font-family: 'Bonbon', 'Roboto', 'Helvetica', sans-serif; color: green;`;
    } else if (sentiment.score >= 0.5) {
      style += `font-family: 'Crafty Girls', 'Roboto', 'Helvetica', sans-serif; color: orange;`;
    } else if (sentiment.score <= -0.9) {
      style += `font-family: 'Creepster', 'Roboto', 'Helvetica', sans-serif; color: red;`;
    } else if (sentiment.score <= -0.5) {
      style += `font-family: 'Julee', 'Roboto', 'Helvetica', sans-serif; color: pink;`;
    } */

    // Make bold if the magnitude is greater than 1.
    /* if (sentiment.magnitude >= 1) {
      style += `font-weight: bold;`;
    } */

    return style ? this.sanitizer.bypassSecurityTrustStyle(style) : '';
  }

}
