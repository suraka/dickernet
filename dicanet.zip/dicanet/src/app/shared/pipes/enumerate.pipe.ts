import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'enumerate'
})
export class EnumeratePipe implements PipeTransform {

  transform(value: number, args: string = ''): any {
    const views = value;
    const thousands = Math.round(Math.abs(views / 1000));
    const millions = Math.round(Math.abs(thousands / 1000));
    const billions = Math.round(Math.abs(millions / 1000));

    if (views <= 999) {
      return `${views} ${args}`;
    } else if (thousands <= 1) {
      return `${thousands} K ${args}`;
    } else if (millions <= 1) {
      return `${millions} M ${args}`;
    } else if (billions <= 1) {
      return `${billions} B ${args}`;
    }
  }

}
