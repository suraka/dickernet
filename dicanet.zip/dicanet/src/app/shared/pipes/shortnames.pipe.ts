import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';

/*
 * Styles a message based on its sentiment.
 */
@Pipe({
  name: 'shorti'
})
export class ShortNamesPipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string, args?: string): any {
    const valueArray = value.split(' ');
    const letters = new Array();

    Array.from(valueArray).forEach((word: string) => {
        letters.push(word.substr(0, 1));
    });

    return letters.join(`${args}`);
  }
}
