import { Component, Input, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

  @Input() width: number | null;
  @Input() height: number | null;

  defaultWith = 21;
  defaultHeight = 20;

  constructor() { }

  ngOnInit() {
    if (this.width) {
      this.defaultWith = this.width;
    } 

    if (this.height) {
      this.defaultHeight = this.height;
    }
  }

}
