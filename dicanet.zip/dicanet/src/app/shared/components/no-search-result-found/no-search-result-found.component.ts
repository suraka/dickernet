import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-no-search-result-found',
  templateUrl: './no-search-result-found.component.html',
  styleUrls: ['./no-search-result-found.component.scss']
})
export class NoSearchResultFoundComponent implements OnInit {

  @Input() searchQuery: string | null;
  @Input() location: string | null;
  @Input() category: string | null;
  public imageStyle: string = `<span class="rounded-circle" style="width: 128px; height: 128px; background-color: darkgrey;"></span>`;
  
  constructor() { }

  ngOnInit() {
  }

}
