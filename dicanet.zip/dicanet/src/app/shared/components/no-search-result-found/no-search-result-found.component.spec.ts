import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoSearchResultFoundComponent } from './no-search-result-found.component';

describe('NoSearchResultFoundComponent', () => {
  let component: NoSearchResultFoundComponent;
  let fixture: ComponentFixture<NoSearchResultFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoSearchResultFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoSearchResultFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
