import { Component, OnInit, Input, Inject, NgZone, ViewChild, OnDestroy, EventEmitter, Output } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

/*
 * Alert Dialog Box
 */
@Component({
  selector: 'alert-dialog',
  templateUrl: 'alert-dialog.component.html',
})
export class AlertDialogComponent implements OnInit {

  @Input() title: string;
  @Input() body: string;
  @Input() icon: string;
  @Input() isIcon: boolean;
  @Input() accept: string; // 'delete', 'remove', 'ok', or 'add'
  @Input() reject: string; // 'cancel', or 'close'
  @Output() acceptAction = new EventEmitter<any>();
  @Output() rejectAction = new EventEmitter<any>();

  constructor(
    public dialogRef: MatDialogRef<AlertDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Partial<any>,
  ) { }

  ngOnInit() { 
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}