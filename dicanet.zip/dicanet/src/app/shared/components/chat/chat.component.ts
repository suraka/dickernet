import { Component, OnInit, Input, OnDestroy, Inject, NgZone, ViewEncapsulation, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm, FormControl } from '@angular/forms';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { AngularFireStorage } from '@angular/fire/storage';
import { map, tap, finalize } from 'rxjs/operators';

import * as firebase from 'firebase/app';
import { MatSnackBar } from '@angular/material/snack-bar';
import { 
  MatBottomSheet, 
  MatBottomSheetRef, 
  MAT_BOTTOM_SHEET_DATA, 
  MatBottomSheetConfig
} from '@angular/material/bottom-sheet';
import { MatStepper } from '@angular/material/stepper';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Observable, Subscription } from 'rxjs';

import { Howl, Howler } from 'howler';

import { User, Ad, Chat, Members, Messages } from './../../../core/models';

import { AuthService, AdService, ChatService, ImageCompressionService } from './../../../core/services';
import * as utility from './../../../core/utility';

// Setup the new Howl.
const incomingMessage = new Howl({
  src: ['./../../../../assets/audio/open-ended.mp3']
});

const outgoingMessage = new Howl({
  src: ['./../../../../assets/audio/pull-out.mp3']
});

const messageAlert = new Howl({
  src: ['./../../../../assets/audio/intuition.mp3']
});

export interface Advertiser {
  otherUser?: User,
  ad?: Ad
}

/* 
 * Chat Component
 */
@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit, OnDestroy {

  //@Input() currentUser?: Partial<User> | null = null; // admin, advertiser, or client
  @Input() otherUser?: Partial<User> | null = null; // admin, advertiser, or client
  @Input() currentUser?: Partial<User> | null = null;
  @Input() ad?: Partial<Ad> | null = null; // ad

  //public showPhone: boolean = false;

  constructor(
    public auth: AuthService,
    private _bottomSheet: MatBottomSheet,
    private _snackBar: MatSnackBar,
    public router: Router
  ) {
  }

  ngOnInit() {
  }

  ngOnDestroy() {
  }

  /* public togglePhone(phone: string) {
    if (this.showPhone) {
      this.showPhone = false;
      return this._snackBar.dismiss();
    }

    const title: string = 'Call';
    const message: string = phone;

    this.openSnackBar(message, title);

    this.showPhone = true;
  } */

  private openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom'
    });
  }

  /*
   * toggle chat for chAat auth or chat room
   */
  toggleChat(): void {
    // play the sound.
    messageAlert.play();

    // change sound volume.
    Howler.volume(1.0);

    if (this.auth.isLoggedIn()) {
      // chat room configuration
      const config: MatBottomSheetConfig = {
        panelClass : [
          'chat-room-container'
        ],
        data: {
          otherUser: this.otherUser,
          ad: this.ad
        }
      };
      // open chat room
      this._bottomSheet.open(ChatRoom, config);
    } else {
      // open chat authentication
      this._bottomSheet.open(ChatAuth);
    }
  }
}

/* 
 * Chat Room Component
 */
@Component({
  selector: 'chat-room',
  templateUrl: 'chat.room.component.html'
})
export class ChatRoom implements OnInit, OnDestroy {
  //@ViewChild('chatMessage', { read: true, static: true }) chatMessageElement: ElementRef;
  //@Input() public otherUser?: User | null = null; // admin, advertiser, or client
  private _loggedInUserMembersSubscription: Subscription;
  public isAlreadyAMember: boolean = false;
  public selectedUser: User | null = null;
  public currentUser$: Observable<User>;
  public loggedInUserMembers$: Observable<Members[]> | null = null;
  //private _membersObjRef: AngularFireObject<Members[]>;
  //public members$: Observable<Members[]> = null;
  //private _chatListRef: AngularFireList<Members>;
  private _currentUserSubscription: Subscription;
  public messages$: Observable<Messages[]> | null;
  public uploadProgress$: Observable<number>;
  public chat: string | null = null;
  public uid: string; // current user ID
  public cid: string; // chat ID
  public lastChat: Observable<Chat> | null = null;
  public swap: boolean = false;
  public isSending: boolean = false;
  public isLoading: boolean = false;
  public isUploading: boolean;
  public error: string; // error message
  private _taskSubscription: Subscription;
  private _downloadURLSubscription: Subscription;
  private _downloadCompressedSubscription: Subscription;

  constructor(
    private _chatRoomRef: MatBottomSheetRef<ChatRoom>,
    private _bottomSheet: MatBottomSheet,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: Advertiser,
    private _afAuth: AngularFireAuth,
    private _afs: AngularFirestore,
    private _afRDb: AngularFireDatabase,
    private _storage: AngularFireStorage,
    private _snackBar: MatSnackBar,
    public auth: AuthService,
    private _chat: ChatService,
    private _imageCompressor: ImageCompressionService,
  ) {
    //this.uid = this._afAuth.auth.currentUser.uid;
    //this._membersObjRef = _afRDb.object(`members/${this.uid}`)
    //this.members$ = this._membersObjRef.valueChanges();
    //this.chatMessages = _afRDb.object(`chats/${this.otherUser.uid}`).valueChanges();
  }

  ngOnInit() {
    if (this.auth.isLoggedIn()) {
      // get current logged in user id
      this.uid = this._afAuth.auth.currentUser.uid;

      // create an observable for user document in firestore
      const loggedInUserRef: AngularFirestoreDocument<User> = this._afs.doc<User>(`users/${this.uid}`);
      this.currentUser$ = loggedInUserRef.valueChanges();

      // create an observable for user members in realtime database
      const loggedInUserMembersRef = this._afRDb.list<Members>(`members/${this.uid}/${this.data.otherUser.uid}`);
      this.loggedInUserMembers$ = loggedInUserMembersRef.valueChanges();

      // subscribe logged in user members in realtime database
      this._loggedInUserMembersSubscription = this.loggedInUserMembers$.subscribe((members) => {
        // loop through members for logged in user
        members.forEach((member) => {
          // access member existance
          this.isAlreadyAMember = member.uid === this.data.otherUser.uid ? true : false;

          // access chat id 
          this.cid = member.uid === this.data.otherUser.uid ? member.cid : '';
          
          if (this.isAlreadyAMember) {
            console.log(this.cid);
            // access all messages linked to this chat id for both users
            const messagesRef = this._afRDb.list<Messages>(`messages/${this.cid}`);
            this.messages$ = messagesRef.valueChanges();
            this.messages$.subscribe(resp => console.log(resp));
          }
        });

        // check member does not exist
        if (!this.isAlreadyAMember) {
          // generate unique chat ID
          this.cid = this._afRDb.createPushId();

          // subscribe logged in user document in firestore
          this._currentUserSubscription = this.currentUser$.subscribe((currentUser) => {
        
            // prepare logged in user document
            const loggedInUser: Members = {
              uid: currentUser.uid,
              cid: this.cid,
              displayName: currentUser.displayName,
              phone: currentUser.phone,
              email: currentUser.email,
              photoUrl: currentUser.photoUrl,
              compressedPhotoUrl: currentUser.compressedPhotoUrl
            }
            
            // prepare other user document
            const otherUser: Members = {
              uid: this.data.otherUser.uid,
              cid: this.cid,
              displayName: this.data.otherUser.displayName,
              phone: this.data.otherUser.phone,
              email: this.data.otherUser.email,
              photoUrl: this.data.otherUser.photoUrl
            }
    
            // setup member reference for both logged in user & the other user
            const loggedInUserMemberRef = this._afRDb.list<Members>(`members/${currentUser.uid}/${this.data.otherUser.uid}`);
            const otherUserMemberRef = this._afRDb.list<Members>(`members/${this.data.otherUser.uid}/${currentUser.uid}`);
            // Use snapshotChanges().map() to store the key
            /* loggedInUserMemberRef.snapshotChanges().pipe(
              map(changes => 
                changes.map(c => ({ key: c.payload.key, ...c.payload.val() }))
              )
            ); */
            // Use snapshotChanges().map() to store the key
            /* otherUserMemberRef.snapshotChanges().pipe(
              map(changes => 
                changes.map(c => ({ key: c.payload.key, ...c.payload.val() }))
              )
            ); */

            loggedInUserMemberRef.push(otherUser); // add other user to logged in user members
            otherUserMemberRef.push(loggedInUser); // add logged in user to other user members
          });
        }

        // last chat reference
        const chatRef = this._afRDb.object<Chat>(`chats/${this.cid}`);

        // access last chat message
        this.lastChat = chatRef.valueChanges();
      });

      // call method on stop typing
      this.updateOnDisconnect();

      // call method on user move to another tab or browser
      this.updateOnAway();
    }
  }

  ngOnDestroy() {
    if (this._loggedInUserMembersSubscription) {
      this._loggedInUserMembersSubscription.unsubscribe();
    }

    if (this._currentUserSubscription) {
      this._currentUserSubscription.unsubscribe();
    }

    if (this._taskSubscription) {
      this._taskSubscription.unsubscribe();
    }

    if (this._downloadURLSubscription) {
      this._downloadURLSubscription.unsubscribe();
    }

    if (this._downloadCompressedSubscription) {
      this._downloadCompressedSubscription.unsubscribe();
    }
  }

  onKeydown(event) {
    // track key events & trigger typing
    if (event.key !== 'Enter' && event.target.value !== null) {
      // typing turn on
      this.setTyping(true);
    } else {
      // typing turn off
      this.setTyping(false);
    }
  }

  // access all chat id messages for both users
  /* getMessages() {
    console.log(this.cid);
    const messagesRef = this._afRDb.list<Messages>(`messages/${this.cid}`);
    this.messages$ = messagesRef.valueChanges();
  } */

  setTyping(typing: boolean) {
    // typing reference
    const typingRef = this._afRDb.object(`typing/${this.uid}/${this.cid}`);

    // toggle typing on/off
    typingRef.set({ isTyping: typing });
  }

  // when user stop typing
  updateOnDisconnect() {
    this._afRDb.object(`typing/${this.uid}/${this.cid}`).query.ref.onDisconnect().update({
      isTyping: false,
    });
  }

  // navigates to a new tab
  updateOnAway() {
    document.onvisibilitychange = (e) => {
      if (document.visibilityState === 'hidden') {
        this.setTyping(false);
      } else if (document.visibilityState === 'visible') {
        this.setTyping(true);
      }
    };
  }

  // get typing info
  get isTyping() {
    return this._afRDb.object(`typing/${this.uid}/${this.cid}`).valueChanges();
  }

  // get user online status
  get isOnline() {
    // status reference
    const statusRef = this._afRDb.object(`status/${this.uid}`);

    return statusRef.valueChanges();
  }

  async sendMessage() {
    this.isSending = true;
    this.error = null;
    //console.log(loggedInUser.displayName);

    const mid = this._afRDb.createPushId();

    const chat: Chat = {
      cid: this.cid,
      lastMessage: this.chat,
      timestamp: firebase.firestore.Timestamp.now().toMillis()
    }

    const message: Messages = {
      mid: mid,
      cid: this.cid,
      from: this.uid,
      to: this.data.otherUser.uid,
      message: {
        text: this.chat
      },
      type: 'text',
      seen: false,
      timestamp: firebase.firestore.Timestamp.now().toMillis()
    }
    
    try {
      // chats & messages reference
      const chatsRef = this._afRDb.object<Chat>(`chats/${this.cid}`);
      const messagesRef = this._afRDb.list<Messages>(`messages/${this.cid}`);

      // add chat last message
      chatsRef.set(chat);

      // add message to the list of messages
      messagesRef.push(message);

      // clear input chat message
      this.chat = null;

    } catch(error) {
      console.log(error.message);
      this.error = error.message;
    }

    this.isSending = false;
  }

  async saveImageMessage(event) {
    // start uploading
    this.isSending = true;
    this.isUploading = true;

    // clear properties
    this.error = null;

    if (!event.target.files[0] || event.target.files[0].length === 0) {
      return this.error = 'You must upload at least one picture';
    }

    // add user id to file metadata
    const metadata = {
      customMetadata: {
        uid: this.uid,
      }
    };

    // get uploaded file
    const file = await this._imageCompressor.resizeImage(event.target.files[0], 520, 1);
    const compressedImage = await this._imageCompressor.resizeImage(file, 45, 0);
    console.log(`original size: ${event.target.files[0].size}, compress size 1: ${file.size} bytes, compress size 2: ${compressedImage.size} bytes`);

    // generate a random number to be use for picture name
    const timestamp = firebase.firestore.Timestamp.now().toMillis();
    const filename = utility.randomIntFromInterval(20, 49) + timestamp;
    console.log(filename);

    // create original && compressed file reference
    const filePath = `chats/${this.cid}/${filename}`;
    const compressedFilePath = `chats/${this.cid}/compressed.${filename}`;
    const fileRef = this._storage.ref(filePath);
    const compressedFileRef = this._storage.ref(compressedFilePath);

    // upload and store both original && compressed
    const task = this._storage.upload(filePath, file, metadata);
    this._storage.upload(compressedFilePath, compressedImage);
    
    // check for errors in uploading
    task.catch(error => {
      console.log(`task: ${error.message}`);
      this.error = error.message;
    });

    // monitor uploading progress
    this.uploadProgress$ = task.percentageChanges();
    console.log('upload chat picture...');

    // get notified when the download url is available
    this._taskSubscription = task.snapshotChanges().pipe(finalize(() => {
      const downloadUrl = fileRef.getDownloadURL();
      const downloadCompressedUrl = compressedFileRef.getDownloadURL();
      this._downloadURLSubscription = downloadUrl.subscribe((photoUrl) => {
        this._downloadCompressedSubscription = downloadCompressedUrl.subscribe(async (compressedPhotoUrl) => {
          
          const mid = this._afRDb.createPushId();
          const timestamp = firebase.firestore.Timestamp.now().toMillis();

          // prepare data to be added to firestore
          const message: Messages = {
            mid: mid,
            cid: this.cid,
            from: this.uid,
            to: this.data.otherUser.uid,
            message: {
              photoUrl: photoUrl,
              compressedPhotoUrl: compressedPhotoUrl
            },
            filename: filename.toString(),
            type: 'photo',
            seen: false,
            timestamp: timestamp
          }

          const chat: Chat = {
            cid: this.cid,
            lastMessage: 'photo',
            timestamp: timestamp
          }

          try {
            // chats & messages reference
            const chatsRef = this._afRDb.object<Chat>(`chats/${this.cid}`);
            const messagesRef = this._afRDb.list<Messages>(`messages/${this.cid}`);
      
            // add chat last message
            chatsRef.set(chat);
      
            // add message to the list of messages
            messagesRef.push(message);
      
          } catch(error) {
            console.log(error.message);
            this.error = error.message;
          }
      
          this.isSending = false;
        });
      });
      this.isUploading = false;
    })).subscribe();
  }

  logout() {
    this.auth.logout();
    this._chatRoomRef.dismiss();
  }

  hideChat() {
    this._chatRoomRef.dismiss();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }
}

/*
 * Chat Authenticate Component
 */
@Component({
  selector: 'chat-auth',
  templateUrl: 'chat.auth.component.html'
})
export class ChatAuth implements OnInit, OnDestroy {
  public isLinear = true;
  public chatAuthFormGroup: FormGroup;
  public color: string = 'primary';
  public swap: boolean = false;
  public isNotANewUser: boolean = true;
  public hide: boolean = true;
  public isLoading: boolean = false;
  public error: string; // error message

  constructor(
    private _chatAuthRef: MatBottomSheetRef<ChatAuth>,
    private _bottomSheet: MatBottomSheet,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _afAuth: AngularFireAuth,
    public auth: AuthService,
  ) { }

  ngOnInit() {
    this.chatAuthFormGroup = new FormGroup({
      firstname: new FormControl(''),
      lastname: new FormControl(''),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)])
    });

    this.chatAuthFormGroup.reset();
  }

  ngOnDestroy() {
  }

  get login() { return this.chatAuthFormGroup.controls; }

  async onSubmitAuthForm() {
    this.isLoading = true;
    this.error = null;

    let response: any;

    // access chat auth form data
    const { firstname, lastname, email, password } = this.chatAuthFormGroup.value;

    // chat room configuration
    const config: MatBottomSheetConfig = {
      panelClass : [
        'chat-room-container'
      ]
    };

    try {
      await this._afAuth.auth.signInWithEmailAndPassword(email, password).then(() => {
        // dismiss chat auth
        this._chatAuthRef.dismiss();

        // stop loading
        this.isLoading = false;
        
        // open chat room
        this._bottomSheet.open(ChatRoom, config);
      }).catch(async (error) => {
        // handle errors rejection.
        if (error.code === 'auth/user-not-found') {
          // create a new user account
          response = await this._afAuth.auth.createUserWithEmailAndPassword(email, password);
          await response.user.updateProfile({displayName: `${firstname} ${lastname}`});
          await this.auth.createUserDocument();

          // stop loading
          this.isLoading = false;

          // dismiss chat auth
          this._chatAuthRef.dismiss();

          // open chat room
          this._bottomSheet.open(ChatRoom, config);
        } else {
          this.error = `Login error ${error.code, error.message}`;
        }
      });
    } catch(error) {
      console.log(error.code, error.message);
      this.error = error.message;
    }
        
    this.isLoading = false;
  }
}