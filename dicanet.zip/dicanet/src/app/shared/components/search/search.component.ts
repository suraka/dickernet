import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { 
  CATEGORIES, PROPERTIES, SERVICES, ELECTRONICS, TECHNOLOGY, FURNITURES, 
  AUTOMOBILES, CARS, TRICYCLES, TRUCKVANBUS, HEAVYDUTY, REGIONS
} from './../../../core/constants.data';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  @Output() locationEvent = new EventEmitter<string>();
  @Output() categoryEvent = new EventEmitter<string>();
  @Output() queryEvent = new EventEmitter<string>();
  public regions = REGIONS;
  public categories = CATEGORIES;
  public properties = PROPERTIES;
  public services = SERVICES;
  public electronics = ELECTRONICS;
  public technology = TECHNOLOGY;
  public furnitures = FURNITURES;
  public automobiles = AUTOMOBILES;
  public cars = CARS;
  public tricycles = TRICYCLES;
  public trucks = TRUCKVANBUS;
  public heavyDuties = HEAVYDUTY;

  public query: string;
  public address: string = 'All Locations';
  public kategory: string = 'All Categories';
  public isChip: boolean = false;
  public selectable = true;
  public removable = true;
  
  constructor() { }

  ngOnInit() { }

  handleLocation(region: string | null) {
    this.isChip = true;
    region === null ? this.address = 'All Locations' : this.address = region;

    this.locationEvent.emit(region);
  }

  handleCategory(category: string | null) {
    this.isChip = true;
    category === null ? this.kategory = 'All Categories' : this.kategory = category;
    
    this.categoryEvent.emit(category);
  }

  onKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.handleQuery(this.query);
    }
  }

  handleQuery(query: string|null) {
    // terminate search if query is less than 4
    /* if (query.length <= 3) {
      return;
    } */

    this.queryEvent.emit(query);
  }

  removeLocation(): void {
    this.handleLocation(null);
  }

  removeCategory(): void {
    this.handleCategory(null);
  }

}
