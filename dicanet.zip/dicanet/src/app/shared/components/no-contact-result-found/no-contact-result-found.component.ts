import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-contact-result-found',
  templateUrl: './no-contact-result-found.component.html',
  styleUrls: ['./no-contact-result-found.component.scss']
})
export class NoContactResultFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
