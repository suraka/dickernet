import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoContactResultFoundComponent } from './no-contact-result-found.component';

describe('NoContactResultFoundComponent', () => {
  let component: NoContactResultFoundComponent;
  let fixture: ComponentFixture<NoContactResultFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoContactResultFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoContactResultFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
