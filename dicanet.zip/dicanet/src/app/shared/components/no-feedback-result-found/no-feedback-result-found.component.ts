import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-no-feedback-result-found',
  templateUrl: './no-feedback-result-found.component.html',
  styleUrls: ['./no-feedback-result-found.component.scss']
})
export class NoFeedbackResultFoundComponent implements OnInit {

  //@Input() feedback: boolean | null;
  //@Input() contact: boolean | null;

  constructor() { }

  ngOnInit() {
  }

}
