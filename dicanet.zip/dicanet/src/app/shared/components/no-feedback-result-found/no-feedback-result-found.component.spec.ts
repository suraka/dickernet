import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoFeedbackResultFoundComponent } from './no-feedback-result-found.component';

describe('NoFeedbackResultFoundComponent', () => {
  let component: NoFeedbackResultFoundComponent;
  let fixture: ComponentFixture<NoFeedbackResultFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoFeedbackResultFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoFeedbackResultFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
