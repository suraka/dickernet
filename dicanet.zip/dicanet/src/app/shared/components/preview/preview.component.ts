import { Component, OnInit, Inject } from '@angular/core';
import { 
  MatBottomSheet, 
  MatBottomSheetRef, 
  MAT_BOTTOM_SHEET_DATA 
} from '@angular/material/bottom-sheet';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss']
})
export class PreviewComponent implements OnInit {

  constructor(
    private _bottomSheet: MatBottomSheet,
  ) { }

  ngOnInit() {
  }

  previewAd(): void {
    this._bottomSheet.open(PreviewAdBottomSheetComponent, {
      data: { 
        email: ['info.dickernet@gmail.com'], 
        info: 'We appreciate your time and our team will follow up on your feedback.'
      },
    });
  }

  previewUser(): void {
    this._bottomSheet.open(PreviewUserBottomSheetComponent, {
      data: { 
        email: ['info.dickernet@gmail.com'], 
        info: 'We appreciate your time and our team will follow up on your feedback.'
      },
    });
  }

}

/**
 * Preview Ad Bottom Sheet
 */
@Component({
  selector: 'preview-ad',
  templateUrl: 'preview.ad.component.html',
})
export class PreviewAdBottomSheetComponent implements OnInit {
 
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private _bottomSheetRef: MatBottomSheetRef<PreviewAdBottomSheetComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit() {
  }

  closeBottomSheetPreviewAd(event: MouseEvent): void {
    this._bottomSheetRef.dismiss();
    event.preventDefault();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }
}

/**
 * Preview User Bottom Sheet
 */
@Component({
  selector: 'preview-user',
  templateUrl: 'preview.user.component.html',
})
export class PreviewUserBottomSheetComponent implements OnInit {
 
  public isLoading: boolean = false;
  public error: string;

  constructor(
    private _bottomSheetRef: MatBottomSheetRef<PreviewUserBottomSheetComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit() {
  }

  closeBottomSheetPreviewUser(event: MouseEvent): void {
    this._bottomSheetRef.dismiss();
    event.preventDefault();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 12000,
    });
  }
}