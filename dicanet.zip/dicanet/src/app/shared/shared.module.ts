import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConnectionServiceModule } from 'ng-connection-service';
import { LazyLoadImageModule } from 'ng-lazyload-image';

import { MaterialModules } from './../material';

import { 
  LoaderComponent, 
  AdComponent, 
  SearchComponent,
  ChatComponent,
  ChatAuth,
  ChatRoom,
  PreviewComponent,
  PreviewAdBottomSheetComponent,
  PreviewUserBottomSheetComponent,
  NoSearchResultFoundComponent,
  NoFeedbackResultFoundComponent,
  NoContactResultFoundComponent,
  NoConnectionComponent,
  AlertComponent, 
  AlertDialogComponent
} from './components';

import {
  TimeAgoPipe,
  TruncateTextPipe,
  EnumeratePipe,
  StylizePipe,
  ShortNamesPipe,
  ShortenTimePipe
} from './pipes';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

export const COMPONENTS = [
  LoaderComponent,
    AdComponent,
    SearchComponent,
    TimeAgoPipe,
    TruncateTextPipe,
    EnumeratePipe,
    ChatComponent,
    StylizePipe,
    ShortNamesPipe,
    ChatAuth,
    ChatRoom,
    NoSearchResultFoundComponent,
    NoFeedbackResultFoundComponent,
    NoContactResultFoundComponent,
    PreviewComponent,
    PreviewAdBottomSheetComponent,
    PreviewUserBottomSheetComponent,
    AlertComponent,
    AlertDialogComponent,
    NoConnectionComponent,
    ShortenTimePipe,
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    MaterialModules,
    ConnectionServiceModule,
    LazyLoadImageModule
  ],
  entryComponents: [
    ChatAuth,
    ChatRoom
  ],
  exports: COMPONENTS,
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false }
    }
  ]
})
export class SharedModule { }
