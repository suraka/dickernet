import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServiceWorkerModule } from '@angular/service-worker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireAuthGuard } from '@angular/fire/auth-guard';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { ConnectionServiceModule } from 'ng-connection-service';

import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { EffectsModule } from '@ngrx/effects';
import { DefaultDataServiceConfig, EntityDataModule } from '@ngrx/data';
import { entityConfig } from './entity-metadata';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
//import { DBModule } from '@ngrx/db';

import { LazyLoadImageModule } from 'ng-lazyload-image';

import { MaterialModules } from './material';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared';

import { CustomSerializer } from './custom-route-serializer';
import { ROOT_REDUCERS, metaReducers } from './reducers';
import { AppEffects } from './app.effects';
import { environment } from '@dickernet/env/environment';
//import { schema } from './db';

import { 
  AuthService, 
  AdService, 
  MessageService, 
  ChatService, 
  KeywordsService,
  ImageCompressionService
} from '@dickernet/app/core/services';

import { InputFocusDirective } from './focus.directive';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { VerifyEmailAddressComponent } from './verify-email-address/verify-email-address.component';
import { NotFoundPageComponent } from './not-found-page/not-found-page.component';

const configErrMsg = `You have not configured and imported the Firebase SDK.
Make sure you go through the codelab setup instructions in https://codelabs.developers.google.com/codelabs/firebase-web/#0`;

const bucketErrMsg = `Your Firebase Storage bucket has not been enabled. Sorry
about that. This is actually a Firebase bug that occurs rarely. Please go and
re-generate the Firebase initialization snippet (step 4 of the codelab) and make
sure the storageBucket attribute is not empty. You may also need to visit the
Storage tab and paste the name of your bucket which is displayed there.`;

if (!environment.firebaseConfig) {
  if (!environment.firebaseConfig.apiKey) {
    window.alert(configErrMsg);
  } else if (environment.firebaseConfig.storageBucket === '') {
    window.alert(bucketErrMsg);
  }
}

export const COMPONENTS = [
  AppComponent,
  HomeComponent,
  HeaderComponent,
  FooterComponent,
  ForgotPasswordComponent,
  VerifyEmailAddressComponent,
  NotFoundPageComponent,
  InputFocusDirective
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    AngularFireDatabaseModule,
    ConnectionServiceModule,

    /**
     * StoreModule.forRoot is imported once in the root module, accepting a reducer
     * function or object map of reducer functions. If passed an object of
     * reducers, combineReducers will be run creating your application
     * meta-reducer. This returns all providers for an @ngrx/store
     * based application.
     */
    StoreModule.forRoot(ROOT_REDUCERS, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true
      }
    }),

    /**
     * Store devtools instrument the store retaining past versions of state
     * and recalculating new states. This enables powerful time-travel
     * debugging.
     *
     * To use the debugger, install the Redux Devtools extension for either
     * Chrome or Firefox
     *
     * See: https://github.com/zalmoxisus/redux-devtools-extension
     */
    StoreDevtoolsModule.instrument({ 
      name: 'Dickernet Web Application',
      maxAge: 25, 
      // Recommendation: disable the Store Devtools in a production build
      logOnly: environment.production 
    }),

    /**
     * EffectsModule.forRoot() is imported once in the root module and
     * sets up the effects class to be initialized immediately when the
     * application starts.
     *
     * See: https://ngrx.io/guide/effects#registering-root-effects
     */
    EffectsModule.forRoot([AppEffects]),

    /**
     * @ngrx/router-store keeps router state up-to-date in the store.
     */
    StoreRouterConnectingModule.forRoot({
      serializer: CustomSerializer
    }),

    //EntityDataModule.forRoot(entityConfig),

    /**
     * `provideDB` sets up @ngrx/db with the provided schema and makes the Database
     * service available.
     */
    //DBModule.provideDB(schema),

    LazyLoadImageModule,
    AppRoutingModule,
    SharedModule,
    MaterialModules,
  ],
  providers: [
    AngularFireAuthGuard, 
    AuthService,
    AdService,
    MessageService,
    ChatService,
    KeywordsService,
    ImageCompressionService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
