/* export * from './header/header.component';
export * from './footer/footer.component';
export * from './home/home.component';
export * from './login/login.component';
export * from './profile/profile.component'; */