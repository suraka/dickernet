const functions = require('firebase-functions');
const nodemailer = require('nodemailer');

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!");
// });

// for sending email:
// 1) enable access to less secure apps
//    https://www.google.com/settings/security/lesssecureapps
// 2) display unlock captcha
//    https://accounts.google.com/displayunlockcaptcha
// 3) gmail account with 2-step verification enabled, you will need to use an app password
//    https://support.google.com/accounts/answer/185833

const gmailEmail = functions.config().gmail.email;
const gmailPassword = functions.config().gmail.password;

const mailTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: gmailEmail,
        pass: gmailPassword
    }
});

const APP_NAME = 'Dickernet';

async function senWelcomeEmail(email, displayName) {
    const mailOptions ={
        from: `${APP_NAME} <info.dickernet@gmail.com>`,
        to: email
    };

    mailOptions.subject = `Welcome to ${APP_NAME}!`;
    mailOptions.text = `Hey ${displayName || ''}! Welcome to this ecommerce platform. You may buy, sell or swap items at any anytime`;

    await mailTransport.sendMail(mailOptions);

    console.log('New welcome email sent to: ', email);

    return null;
}

exports.senWelcomeEmail = functions.auth.user().onCreate((user) => {
    const email = user.email;
    const displayName = user.displayName;

    return senWelcomeEmail(email, displayName);
})