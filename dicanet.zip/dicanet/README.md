# Dickernet

This project is based on angular and firebase. It was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.20

## Angular

Is a TypeScript-based open-source web application framework led by the Angular Team at Google and by a community of individuals and corporations. [About Angular](https://angular.io/).

## Firebase

Is a mobile and web application development platform developed by Firebase, Inc. in 2011, then acquired by Google in 2014. As of October 2018, the Firebase platform has 18 products, which are used by 1.5 million apps. [About Firebase](https://firebase.google.com/).

## PRECAUTIONS
1. All the Run commands are done in the command prompt / terminal 
1. Use administrative privileges to perform npm starting command.
1. Wait for each installation or instruction to complete before moving to the next step.

## Installations & Setting up Dickernet

To get started, follow these instructions:

1. Ensure that you have a stable internet connectivity
1. Make sure that you have Node 10.13 or later installed. See instructions [here](https://nodejs.org/en/download/).
1. Unzipped the dickernet zip file into your chosen location on your computer.
1. Open your command prompt or terminal and navigate to the dickernet folder.
1. Run `npm view @angular/cli` This will display all available versions of angular if you're interested. 
1. Run `npm install -g @angular/cli@8.3.23` See instructions [here](https://cli.angular.io/).
1. Run `npm install -g firebase-tools` See instructions [here](https://firebase.google.com/docs/cli).
1. 
1. Run `firebase login` This will guide you to sign into Firebase using your Google account.
1. Run `firebase init` in the command prompt. This will initialize a Firebase project for dickernet.

1. Make sure you have vscode editor installed. See instructions [here](https://code.visualstudio.com/).
1. Open vscode application after installation.
1. Click on File and goto Open... in the menu bar.
1. Navigate to the dickernet folder and click Open.
1. 
1. 

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
